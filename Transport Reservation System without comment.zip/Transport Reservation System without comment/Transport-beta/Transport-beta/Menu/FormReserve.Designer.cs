﻿
namespace Transport_beta.Menu
{
    partial class FormReserve
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCost = new System.Windows.Forms.Label();
            this.labelFillall = new System.Windows.Forms.Label();
            this.TotalCost = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cboxDay = new System.Windows.Forms.ComboBox();
            this.lblMin = new System.Windows.Forms.Label();
            this.lblHour = new System.Windows.Forms.Label();
            this.cboxMin = new System.Windows.Forms.ComboBox();
            this.cboxHour = new System.Windows.Forms.ComboBox();
            this.textTo = new Guna.UI2.WinForms.Guna2TextBox();
            this.textFrom = new Guna.UI2.WinForms.Guna2TextBox();
            this.ReserveDate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.lblDuration = new System.Windows.Forms.Label();
            this.lblTo = new System.Windows.Forms.Label();
            this.lblFrom = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.labelUsername = new System.Windows.Forms.Label();
            this.labelModel = new System.Windows.Forms.Label();
            this.cboxModel = new System.Windows.Forms.ComboBox();
            this.btnReserve = new Guna.UI2.WinForms.Guna2Button();
            this.labelBrand = new System.Windows.Forms.Label();
            this.cboxBrand = new System.Windows.Forms.ComboBox();
            this.labelType = new System.Windows.Forms.Label();
            this.cboxType = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.BackColor = System.Drawing.Color.Transparent;
            this.lblCost.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCost.Location = new System.Drawing.Point(388, 411);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(0, 22);
            this.lblCost.TabIndex = 56;
            // 
            // labelFillall
            // 
            this.labelFillall.AutoSize = true;
            this.labelFillall.BackColor = System.Drawing.Color.Transparent;
            this.labelFillall.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelFillall.Font = new System.Drawing.Font("Segoe UI Semibold", 12.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFillall.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelFillall.Location = new System.Drawing.Point(419, 410);
            this.labelFillall.Name = "labelFillall";
            this.labelFillall.Size = new System.Drawing.Size(144, 23);
            this.labelFillall.TabIndex = 55;
            this.labelFillall.Text = "*Fill all the details";
            this.labelFillall.Visible = false;
            // 
            // TotalCost
            // 
            this.TotalCost.AutoSize = true;
            this.TotalCost.BackColor = System.Drawing.Color.Transparent;
            this.TotalCost.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalCost.Location = new System.Drawing.Point(480, 382);
            this.TotalCost.Name = "TotalCost";
            this.TotalCost.Size = new System.Drawing.Size(0, 19);
            this.TotalCost.TabIndex = 50;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(419, 354);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 23);
            this.label6.TabIndex = 49;
            this.label6.Text = "Day";
            // 
            // cboxDay
            // 
            this.cboxDay.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cboxDay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxDay.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxDay.FormattingEnabled = true;
            this.cboxDay.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30"});
            this.cboxDay.Location = new System.Drawing.Point(373, 352);
            this.cboxDay.MaxDropDownItems = 1;
            this.cboxDay.Name = "cboxDay";
            this.cboxDay.Size = new System.Drawing.Size(44, 30);
            this.cboxDay.TabIndex = 48;
            this.cboxDay.SelectedValueChanged += new System.EventHandler(this.cboxDay_SelectedValueChanged);
            // 
            // lblMin
            // 
            this.lblMin.AutoSize = true;
            this.lblMin.BackColor = System.Drawing.Color.Transparent;
            this.lblMin.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMin.Location = new System.Drawing.Point(637, 354);
            this.lblMin.Name = "lblMin";
            this.lblMin.Size = new System.Drawing.Size(70, 23);
            this.lblMin.TabIndex = 47;
            this.lblMin.Text = "Minute";
            // 
            // lblHour
            // 
            this.lblHour.AutoSize = true;
            this.lblHour.BackColor = System.Drawing.Color.Transparent;
            this.lblHour.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHour.Location = new System.Drawing.Point(522, 354);
            this.lblHour.Name = "lblHour";
            this.lblHour.Size = new System.Drawing.Size(54, 23);
            this.lblHour.TabIndex = 46;
            this.lblHour.Text = "Hour";
            // 
            // cboxMin
            // 
            this.cboxMin.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cboxMin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxMin.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxMin.FormattingEnabled = true;
            this.cboxMin.Items.AddRange(new object[] {
            "00",
            "10",
            "20",
            "30",
            "40",
            "50"});
            this.cboxMin.Location = new System.Drawing.Point(591, 352);
            this.cboxMin.MaxDropDownItems = 1;
            this.cboxMin.Name = "cboxMin";
            this.cboxMin.Size = new System.Drawing.Size(44, 30);
            this.cboxMin.TabIndex = 45;
            this.cboxMin.SelectedValueChanged += new System.EventHandler(this.cboxMin_SelectedValueChanged);
            // 
            // cboxHour
            // 
            this.cboxHour.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cboxHour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxHour.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxHour.FormattingEnabled = true;
            this.cboxHour.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24"});
            this.cboxHour.Location = new System.Drawing.Point(476, 352);
            this.cboxHour.MaxDropDownItems = 1;
            this.cboxHour.Name = "cboxHour";
            this.cboxHour.Size = new System.Drawing.Size(44, 30);
            this.cboxHour.TabIndex = 44;
            this.cboxHour.SelectedValueChanged += new System.EventHandler(this.cboxHour_SelectedValueChanged);
            // 
            // textTo
            // 
            this.textTo.AcceptsReturn = true;
            this.textTo.BackColor = System.Drawing.Color.Transparent;
            this.textTo.BorderRadius = 10;
            this.textTo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textTo.DefaultText = "";
            this.textTo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textTo.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textTo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textTo.DisabledState.Parent = this.textTo;
            this.textTo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textTo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textTo.FocusedState.Parent = this.textTo;
            this.textTo.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textTo.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textTo.HoverState.Parent = this.textTo;
            this.textTo.Location = new System.Drawing.Point(538, 299);
            this.textTo.Margin = new System.Windows.Forms.Padding(5);
            this.textTo.Name = "textTo";
            this.textTo.PasswordChar = '\0';
            this.textTo.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textTo.PlaceholderText = "";
            this.textTo.SelectedText = "";
            this.textTo.ShadowDecoration.Parent = this.textTo;
            this.textTo.Size = new System.Drawing.Size(117, 31);
            this.textTo.TabIndex = 43;
            // 
            // textFrom
            // 
            this.textFrom.AcceptsReturn = true;
            this.textFrom.BackColor = System.Drawing.Color.Transparent;
            this.textFrom.BorderRadius = 10;
            this.textFrom.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textFrom.DefaultText = "";
            this.textFrom.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textFrom.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textFrom.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textFrom.DisabledState.Parent = this.textFrom;
            this.textFrom.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textFrom.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textFrom.FocusedState.Parent = this.textFrom;
            this.textFrom.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textFrom.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textFrom.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textFrom.HoverState.Parent = this.textFrom;
            this.textFrom.Location = new System.Drawing.Point(346, 299);
            this.textFrom.Margin = new System.Windows.Forms.Padding(5);
            this.textFrom.Name = "textFrom";
            this.textFrom.PasswordChar = '\0';
            this.textFrom.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textFrom.PlaceholderText = "";
            this.textFrom.SelectedText = "";
            this.textFrom.ShadowDecoration.Parent = this.textFrom;
            this.textFrom.Size = new System.Drawing.Size(117, 31);
            this.textFrom.TabIndex = 42;
            // 
            // ReserveDate
            // 
            this.ReserveDate.BackColor = System.Drawing.Color.Transparent;
            this.ReserveDate.BorderRadius = 5;
            this.ReserveDate.CheckedState.Parent = this.ReserveDate;
            this.ReserveDate.FillColor = System.Drawing.SystemColors.ControlLightLight;
            this.ReserveDate.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReserveDate.ForeColor = System.Drawing.Color.Black;
            this.ReserveDate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.ReserveDate.HoverState.Parent = this.ReserveDate;
            this.ReserveDate.Location = new System.Drawing.Point(392, 249);
            this.ReserveDate.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.ReserveDate.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.ReserveDate.Name = "ReserveDate";
            this.ReserveDate.ShadowDecoration.Parent = this.ReserveDate;
            this.ReserveDate.Size = new System.Drawing.Size(220, 33);
            this.ReserveDate.TabIndex = 37;
            this.ReserveDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ReserveDate.Value = new System.DateTime(2021, 7, 24, 13, 14, 7, 837);
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.BackColor = System.Drawing.Color.Transparent;
            this.lblTotalCost.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalCost.Location = new System.Drawing.Point(271, 410);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(108, 23);
            this.lblTotalCost.TabIndex = 16;
            this.lblTotalCost.Text = "Total Cost :";
            // 
            // lblDuration
            // 
            this.lblDuration.AutoSize = true;
            this.lblDuration.BackColor = System.Drawing.Color.Transparent;
            this.lblDuration.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDuration.Location = new System.Drawing.Point(271, 354);
            this.lblDuration.Name = "lblDuration";
            this.lblDuration.Size = new System.Drawing.Size(96, 23);
            this.lblDuration.TabIndex = 15;
            this.lblDuration.Text = "Duration :";
            // 
            // lblTo
            // 
            this.lblTo.AutoSize = true;
            this.lblTo.BackColor = System.Drawing.Color.Transparent;
            this.lblTo.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTo.Location = new System.Drawing.Point(487, 307);
            this.lblTo.Name = "lblTo";
            this.lblTo.Size = new System.Drawing.Size(43, 23);
            this.lblTo.TabIndex = 14;
            this.lblTo.Text = "To :";
            // 
            // lblFrom
            // 
            this.lblFrom.AutoSize = true;
            this.lblFrom.BackColor = System.Drawing.Color.Transparent;
            this.lblFrom.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFrom.Location = new System.Drawing.Point(271, 307);
            this.lblFrom.Name = "lblFrom";
            this.lblFrom.Size = new System.Drawing.Size(67, 23);
            this.lblFrom.TabIndex = 13;
            this.lblFrom.Text = "From :";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.BackColor = System.Drawing.Color.Transparent;
            this.lblDate.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(271, 256);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(60, 23);
            this.lblDate.TabIndex = 12;
            this.lblDate.Text = "Date :";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.BackColor = System.Drawing.Color.Transparent;
            this.lblUser.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.Location = new System.Drawing.Point(388, 54);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(0, 22);
            this.lblUser.TabIndex = 11;
            // 
            // labelUsername
            // 
            this.labelUsername.AutoSize = true;
            this.labelUsername.BackColor = System.Drawing.Color.Transparent;
            this.labelUsername.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUsername.Location = new System.Drawing.Point(271, 53);
            this.labelUsername.Name = "labelUsername";
            this.labelUsername.Size = new System.Drawing.Size(104, 23);
            this.labelUsername.TabIndex = 10;
            this.labelUsername.Text = "Username :";
            // 
            // labelModel
            // 
            this.labelModel.AutoSize = true;
            this.labelModel.BackColor = System.Drawing.Color.Transparent;
            this.labelModel.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelModel.Location = new System.Drawing.Point(271, 201);
            this.labelModel.Name = "labelModel";
            this.labelModel.Size = new System.Drawing.Size(75, 23);
            this.labelModel.TabIndex = 6;
            this.labelModel.Text = "Model :";
            // 
            // cboxModel
            // 
            this.cboxModel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cboxModel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxModel.Enabled = false;
            this.cboxModel.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxModel.FormattingEnabled = true;
            this.cboxModel.Location = new System.Drawing.Point(392, 194);
            this.cboxModel.MaxDropDownItems = 1;
            this.cboxModel.Name = "cboxModel";
            this.cboxModel.Size = new System.Drawing.Size(263, 30);
            this.cboxModel.TabIndex = 5;
            this.cboxModel.SelectedIndexChanged += new System.EventHandler(this.cboxModel_SelectedIndexChanged);
            // 
            // btnReserve
            // 
            this.btnReserve.BorderRadius = 20;
            this.btnReserve.CheckedState.Parent = this.btnReserve;
            this.btnReserve.CustomImages.Parent = this.btnReserve;
            this.btnReserve.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnReserve.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnReserve.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnReserve.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnReserve.DisabledState.Parent = this.btnReserve;
            this.btnReserve.FillColor = System.Drawing.Color.IndianRed;
            this.btnReserve.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReserve.ForeColor = System.Drawing.Color.White;
            this.btnReserve.HoverState.Parent = this.btnReserve;
            this.btnReserve.Location = new System.Drawing.Point(436, 452);
            this.btnReserve.Name = "btnReserve";
            this.btnReserve.ShadowDecoration.Parent = this.btnReserve;
            this.btnReserve.Size = new System.Drawing.Size(81, 45);
            this.btnReserve.TabIndex = 4;
            this.btnReserve.Text = "Reserve";
            this.btnReserve.Click += new System.EventHandler(this.btnReserve_Click);
            // 
            // labelBrand
            // 
            this.labelBrand.AutoSize = true;
            this.labelBrand.BackColor = System.Drawing.Color.Transparent;
            this.labelBrand.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBrand.Location = new System.Drawing.Point(271, 155);
            this.labelBrand.Name = "labelBrand";
            this.labelBrand.Size = new System.Drawing.Size(71, 23);
            this.labelBrand.TabIndex = 3;
            this.labelBrand.Text = "Brand :";
            // 
            // cboxBrand
            // 
            this.cboxBrand.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cboxBrand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxBrand.Enabled = false;
            this.cboxBrand.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxBrand.FormattingEnabled = true;
            this.cboxBrand.Location = new System.Drawing.Point(392, 148);
            this.cboxBrand.MaxDropDownItems = 6;
            this.cboxBrand.Name = "cboxBrand";
            this.cboxBrand.Size = new System.Drawing.Size(263, 30);
            this.cboxBrand.TabIndex = 2;
            this.cboxBrand.SelectedIndexChanged += new System.EventHandler(this.cboxBrand_SelectedIndexChanged);
            // 
            // labelType
            // 
            this.labelType.AutoSize = true;
            this.labelType.BackColor = System.Drawing.Color.Transparent;
            this.labelType.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelType.Location = new System.Drawing.Point(271, 109);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(60, 23);
            this.labelType.TabIndex = 1;
            this.labelType.Text = "Type :";
            // 
            // cboxType
            // 
            this.cboxType.AllowDrop = true;
            this.cboxType.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cboxType.DisplayMember = "Type";
            this.cboxType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxType.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxType.FormattingEnabled = true;
            this.cboxType.Location = new System.Drawing.Point(392, 102);
            this.cboxType.MaxDropDownItems = 7;
            this.cboxType.Name = "cboxType";
            this.cboxType.Size = new System.Drawing.Size(263, 30);
            this.cboxType.TabIndex = 0;
            this.cboxType.ValueMember = "Type";
            this.cboxType.SelectedIndexChanged += new System.EventHandler(this.cbType_SelectedIndexChanged);
            // 
            // FormReserve
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1013, 552);
            this.Controls.Add(this.lblCost);
            this.Controls.Add(this.labelFillall);
            this.Controls.Add(this.TotalCost);
            this.Controls.Add(this.cboxBrand);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cboxType);
            this.Controls.Add(this.cboxDay);
            this.Controls.Add(this.labelType);
            this.Controls.Add(this.lblMin);
            this.Controls.Add(this.labelBrand);
            this.Controls.Add(this.lblHour);
            this.Controls.Add(this.btnReserve);
            this.Controls.Add(this.cboxMin);
            this.Controls.Add(this.cboxModel);
            this.Controls.Add(this.cboxHour);
            this.Controls.Add(this.labelModel);
            this.Controls.Add(this.textTo);
            this.Controls.Add(this.labelUsername);
            this.Controls.Add(this.textFrom);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.ReserveDate);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblTotalCost);
            this.Controls.Add(this.lblFrom);
            this.Controls.Add(this.lblDuration);
            this.Controls.Add(this.lblTo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormReserve";
            this.Text = "Reservation";
            this.Load += new System.EventHandler(this.FormReserve_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.ComboBox cboxType;
        private Guna.UI2.WinForms.Guna2Button btnReserve;
        private System.Windows.Forms.Label labelBrand;
        private System.Windows.Forms.ComboBox cboxBrand;
        private System.Windows.Forms.Label labelModel;
        private System.Windows.Forms.ComboBox cboxModel;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.Label lblDuration;
        private System.Windows.Forms.Label lblTo;
        private System.Windows.Forms.Label lblFrom;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label labelUsername;
        private Guna.UI2.WinForms.Guna2DateTimePicker ReserveDate;
        private System.Windows.Forms.Label lblMin;
        private System.Windows.Forms.Label lblHour;
        private System.Windows.Forms.ComboBox cboxMin;
        private System.Windows.Forms.ComboBox cboxHour;
        private Guna.UI2.WinForms.Guna2TextBox textTo;
        private Guna.UI2.WinForms.Guna2TextBox textFrom;
        private System.Windows.Forms.Label TotalCost;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cboxDay;
        private System.Windows.Forms.Label labelFillall;
        private System.Windows.Forms.Label lblCost;
    }
}