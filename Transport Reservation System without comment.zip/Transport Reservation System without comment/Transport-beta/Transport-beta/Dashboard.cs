﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TRSDatabase.AppConnect;

namespace Transport_beta
{
    public partial class Dashboard : Form
    {
        private Button CurrentButton;
        private Random random;
        private int tempIndex;
        private Form activeForm;

        public Dashboard()
        {
            InitializeComponent();
            random = new Random();
        }

        public Color SelectColor()
        {
            int index = random.Next(ThemeColor.ColorList.Count);
            while ( tempIndex == index)
            {
                index = random.Next(ThemeColor.ColorList.Count);
            }
            tempIndex = index;
            string color = ThemeColor.ColorList[index];
            return ColorTranslator.FromHtml(color);
        }

        private void ActiveButton ( object btnSent)
        {
            if (btnSent != null)
            {
                if (CurrentButton != (Button)btnSent)
                {
                    DisableButton();

                    Color color = SelectColor();
                    CurrentButton = (Button)btnSent;
                    CurrentButton.BackColor = color;
                    CurrentButton.ForeColor = Color.White;
                    CurrentButton.Font = new Font("Times New Roman", 18F,FontStyle.Regular, GraphicsUnit.Point, ((byte)(0)));
                    panelTitleBar.BackColor = color;
                    panelLogo.BackColor = ThemeColor.ChangeColorBrightness(color, -0.3);
                    ThemeColor.PrimaryColor = color;
                    ThemeColor.SecondaryColor = ThemeColor.ChangeColorBrightness(color, -0.3);
                }
            }
        }

        private void DisableButton()
        {
            foreach(Control previousBtn in panelMenu.Controls)
            {
                if (previousBtn.GetType() == typeof(Button))
                {
                    previousBtn.BackColor = Color.FromArgb(51, 51, 76);
                    previousBtn.ForeColor = Color.White;
                    previousBtn.Font = new Font("Times New Roman", 15.75F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(0)));
                }     
            }
        }

        private void OpenChildForm ( Form childForm, object btnSent)
        {
            if(activeForm != null)
               activeForm.Close();

            ActiveButton(btnSent);
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panelDashboard.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
            labelTitle.Text = childForm.Text;
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            ActiveButton(sender);

            if (activeForm != null)
                activeForm.Close();
            Reset();
        }

        private void Reset()
        {
            DisableButton();
            labelTitle.Text = "Welcome! " + FormLogin.Fullname.ToUpper();
            labelTitle.ForeColor = Color.Black;
            panelTitleBar.BackColor = Color.YellowGreen;
            panelLogo.BackColor = ThemeColor.ChangeColorBrightness(Color.YellowGreen, -0.3); 
            CurrentButton = null;
        }

        private void btnReserve_Click_2(object sender, EventArgs e)
        {
            OpenChildForm(new Menu.FormReserve(), sender);
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Menu.FormHistory(), sender);
        }

        private void btnTransport_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Menu.FormTransport(), sender);
        }

        private void btnUser_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Menu.FormUser(), sender);
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            if (new OUserLogin().checkUser(FormLogin.Username) == "Admin")
            {
                btnTransport.Visible = true;
                btnUser.Visible = true;
            }
            new FormLogin().Show();
            this.Close();
        }

        private void btnAppClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMinimise_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        private void panelTitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            Reset();
            //Check user type
            if ( new OUserLogin().checkUser(FormLogin.Username) == "Admin")
            {
                btnTransport.Visible = true;
                btnUser.Visible = true;
                btnReserve.Visible = false;
            }
        }

    }
}
