﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TRSDatabase.AppOperation;

namespace Transport_beta.Menu
{
    public partial class FormHistory : Form
    {
        public FormHistory()
        {
            InitializeComponent();
        }
        
        private void FormHistory_Load(object sender, EventArgs e)
        {
            //Display users reservation history
            SqlDataAdapter sqlda = new OHistory().RHistory(FormLogin.Username);
            DataTable dt = new DataTable();
            sqlda.Fill(dt);
            dataGridHistory.DataSource = dt;
        }
    }
}
