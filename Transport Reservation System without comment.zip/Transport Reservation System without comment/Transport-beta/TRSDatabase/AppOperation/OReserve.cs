﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TRSDatabase.AppInfo;

namespace TRSDatabase.AppOperation
{
    public class OReserve
    {
        SqlConnection DBconnect = new SqlConnection("Data Source=DESKTOP-H84DT5K;Initial Catalog=TRSalpha;Integrated Security=True");
    
        public int Reserve(InfoReserve r)
        {
            DBconnect.Open();
            SqlCommand cmd1 = new SqlCommand("Insert into Reservation values('"+r.Username+"','"+r.Date+"','"+r.Duration+"','"+r.From+
                                "','"+r.To+"','"+r.Type+"','"+r.Brand+"','"+r.Model+"','"+r.TotalCost+"')", DBconnect);

            SqlCommand cmd2 = new SqlCommand("Update Transports set Available = 'No' Where Type='"+r.Type+"' AND Brand='"+r.Brand+"' AND Model='"+r.Model+
                                "' AND Available ='Yes' AND Fare =(SELECT MIN(Fare) from Transports Where Type='"+r.Type+"' AND Brand='"+r.Brand+
                                "' AND Model='"+r.Model+"' AND Available ='Yes')", DBconnect);
            int flag = cmd1.ExecuteNonQuery();
            cmd2.ExecuteNonQuery();
            DBconnect.Close();
            return flag;
        }
        public double GetFare(string Rtype, string Rbrand, string Rmodel)
        {
            DBconnect.Open();
            SqlCommand cmd0 = new SqlCommand("SELECT Fare FROM Transports Where Type='"+Rtype+"' AND Brand='"+Rbrand+"' AND Model='"+Rmodel+
                                                    "' AND Available ='Yes' Order By Fare", DBconnect);
            SqlDataReader sqlDr0 = cmd0.ExecuteReader();
            sqlDr0.Read();
            double fare = Double.Parse(sqlDr0.GetString(0));
            DBconnect.Close();
            return fare;
        }

        //For Type
        public List<string> TransportColumn()
        {
            DBconnect.Open();
            SqlCommand cmd0 = new SqlCommand("Select DISTINCT Type from Transports Order By Type", DBconnect);
            SqlDataReader sqlDr = cmd0.ExecuteReader();
            List<string> Types = new List<string>();
            while (sqlDr.Read())
            {
                string Type = sqlDr.GetString(0);
                Types.Add(Type);
            }
            DBconnect.Close();
            return Types;
        }

        //For Brand
        public List<string> TransportColumn(string Rtype)
        {
            DBconnect.Open();
            SqlCommand cmd0 = new SqlCommand("Select DISTINCT Brand from Transports where Type='"+Rtype+ "' AND Available='Yes' Order By Brand", DBconnect);
            SqlDataReader sqlDr = cmd0.ExecuteReader();
            List<string> Brands = new List<string>();
            while (sqlDr.Read())
            {
                string Brand = sqlDr.GetString(0);
                Brands.Add(Brand);
            }
            DBconnect.Close();
            return Brands;
        }

        //For Model
        public List<string> TransportColumn(string Rtype, string Rbrand)
        {
            DBconnect.Open();
            SqlCommand cmd0 = new SqlCommand("Select DISTINCT Model from Transports where Type='"+Rtype+"' AND Brand='"+Rbrand+"' AND Available='Yes' Order By Model", DBconnect);
            SqlDataReader sqlDr = cmd0.ExecuteReader();
            List<string> Models = new List<string>();
            while (sqlDr.Read())
            {
                string Model = sqlDr.GetString(0);
                Models.Add(Model);
            }
            DBconnect.Close();
            return Models;
        }
       
    }
}
