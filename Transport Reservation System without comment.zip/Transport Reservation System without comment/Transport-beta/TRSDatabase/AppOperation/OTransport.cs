﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TRSDatabase.AppInfo;

namespace TRSDatabase.AppOperation
{
    public class OTransport
    {
        SqlConnection DBconnect = new SqlConnection("Data Source=DESKTOP-H84DT5K;Initial Catalog=TRSalpha;Integrated Security=True");

        public int AddTransport(InfoTransport t)
        {
            string query = "Insert into Transports values('" + t.RegNo + "','" + t.Type + "','" + t.Brand + "','" +
            t.Model + "','" + t.Fare + "','" + t.Available + "')";

            DBconnect.Open();
            SqlCommand cmd0 = new SqlCommand("Select * from Transports where regNo='" + t.RegNo + "'", DBconnect);
            SqlDataReader found = cmd0.ExecuteReader();

            if (!found.HasRows)
            {
                found.Close();
                SqlCommand cmd = new SqlCommand(query, DBconnect);
                int flag = cmd.ExecuteNonQuery();
                DBconnect.Close();
                return flag;
            }
            else
            {
                DBconnect.Close();
                return 0;
            }
        }

        public SqlDataAdapter ShowTransport()
        {
            DBconnect.Open();
            SqlDataAdapter sqlDa = new SqlDataAdapter("Select * from Transports", DBconnect);
            DBconnect.Close();
            return sqlDa;
        }

        public int EditTransport(InfoTransport t)
        {
            string query = "Update Transports set Type='" + t.Type + "', Brand='" + t.Brand + "', Model='" +
                                   t.Model + "', Fare='" + t.Fare + "', Available='" + t.Available + "' where regNo='"+t.RegNo+"'";

            DBconnect.Open();
            SqlCommand cmd0 = new SqlCommand("Select * from Transports where regNo='" + t.RegNo + "'", DBconnect);
            SqlDataReader found = cmd0.ExecuteReader();

            if (found.HasRows)
            {
                found.Close();
                SqlCommand cmd = new SqlCommand(query, DBconnect);
                int flag = cmd.ExecuteNonQuery();
                DBconnect.Close();

                return flag;
            }
            else
            {
                DBconnect.Close();
                return 0;
            }
        }

        public int DeleteTransport(InfoTransport t)
        {
            string query = "Delete from Transports where regNo = '" + t.RegNo + "'";

            DBconnect.Open();
            SqlCommand cmd0 = new SqlCommand("Select * from Transports where regNo='" + t.RegNo + "'", DBconnect);
            SqlDataReader found = cmd0.ExecuteReader();

            if (found.HasRows)
            {
                found.Close();
                SqlCommand cmd = new SqlCommand(query, DBconnect);
                int flag = cmd.ExecuteNonQuery();
                DBconnect.Close();

                return flag;
            }
            else
            {
                DBconnect.Close();
                return 0;
            }
        }
    }
}