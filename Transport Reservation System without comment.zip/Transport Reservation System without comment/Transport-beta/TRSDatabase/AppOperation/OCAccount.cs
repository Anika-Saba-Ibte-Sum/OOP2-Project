﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TRSDatabase.AppInfo;

namespace TRSDatabase.AppConnect
{
    public class OCAccount
    {
        SqlConnection DBconnect = new SqlConnection("Data Source=DESKTOP-H84DT5K;Initial Catalog=TRSalpha;Integrated Security=True");
        public int Add(InfoUser i)//Creating new account
        {
            string query = "insert into UserLogin values('" + i.Username + "','" + i.Password + "');" +
                            "insert into UserInfo values('"+  i.Fname + "','" + i.Lname + "','" + i.NidNo + "','" + 
                                i.Email + "','" + i.PhoneNo + "','" + i.Address + "','" + i.Gender + "','" +
                                i.Dob + "','" + i.Username + "','" + i.Password + "','"+i.Role+"');";

            DBconnect.Open();
            SqlCommand cmd0 = new SqlCommand("Select * from UserInfo where username='" + i.Username + "'", DBconnect);
            SqlDataReader found = cmd0.ExecuteReader();

            if (!found.HasRows)
            {
                found.Close();

                SqlCommand cmd = new SqlCommand(query, DBconnect);
                int flag = cmd.ExecuteNonQuery();
                DBconnect.Close();

                return flag;
            }
            else
            {
                DBconnect.Close();
                return 2;
            }
        }

        public int Update(InfoUser i)//Update information
        {
            string query = "Update UserLogin set Password ='"+i.Password+"' Where Username='"+i.Username+"';"+
                "Update UserInfo set Fname='"+i.Fname+"', Lname='"+i.Lname+"', [Nid No]='"+i.NidNo+"', Dob='"+i.Dob+"', [E-Mail]='"+i.Email+
                "', [Phone No]='"+i.PhoneNo+"', Address ='"+i.Address+"', Gender ='"+i.Gender+"', Password ='"+i.Password+"',  Role='"+i.Role+"' Where Username='"+i.Username+"'";
                

            DBconnect.Open();
            SqlCommand cmd0 = new SqlCommand("Select * from UserInfo where username='" + i.Username + "'", DBconnect);
            SqlDataReader found = cmd0.ExecuteReader();

            if (found.HasRows)
            {
                found.Close();
                SqlCommand cmd = new SqlCommand(query, DBconnect);
                int flag = cmd.ExecuteNonQuery();
                DBconnect.Close();

                return flag;
            }
            else
            {
                DBconnect.Close();
                return 0;
            }
        }

        public int Delete(InfoUser i)//Delete Accounting
        {
            string query = "Delete from UserLogin where Username ='" + i.Username + "';"+
                        "Delete from UserInfo where Username ='" + i.Username + "';";

            DBconnect.Open();
            SqlCommand cmd0 = new SqlCommand("Select * from UserInfo where username='" + i.Username + "'", DBconnect);
            SqlDataReader found = cmd0.ExecuteReader();

            if (found.HasRows)
            {
                found.Close();
                SqlCommand cmd = new SqlCommand(query, DBconnect);
                int flag = cmd.ExecuteNonQuery();
                DBconnect.Close();

                return flag;
            }
            else
            {
                DBconnect.Close();
                return 0;
            }
        }

        public SqlDataAdapter ShowUsers()
        {
            DBconnect.Open();
            SqlDataAdapter sqlDa = new SqlDataAdapter("Select Username as [User], Password as Pass, Role, Fname, Lname, " +
                "[Nid No] as NID, [E-mail], [Phone No] as Phone, Address, Gender, Dob as DoB from Userinfo " +
                "Order By Username", DBconnect);
            DBconnect.Close();
            return sqlDa;
        }
        public string Fullname(string username)
        {
            DBconnect.Open();
            SqlCommand cmd0 = new SqlCommand("SELECT Fname,Lname FROM UserInfo Where Username='"+username+"'", DBconnect);
            SqlDataReader sqlDr0 = cmd0.ExecuteReader();
            sqlDr0.Read();
            String name1 = (sqlDr0.GetString(0));
            String name2 = (sqlDr0.GetString(1));
            DBconnect.Close();
            return name1+" "+name2 ;
        }
    }
}