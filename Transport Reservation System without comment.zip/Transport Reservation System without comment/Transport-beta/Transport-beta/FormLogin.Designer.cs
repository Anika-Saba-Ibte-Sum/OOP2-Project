﻿
namespace Transport_beta
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelLogin = new System.Windows.Forms.Panel();
            this.panelTitleBar = new System.Windows.Forms.Panel();
            this.btnMinimise = new System.Windows.Forms.Button();
            this.btnAppClose = new System.Windows.Forms.Button();
            this.panelLogin2 = new System.Windows.Forms.Panel();
            this.cbtnShowPass = new Guna.UI2.WinForms.Guna2CircleButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnLogIn = new Guna.UI2.WinForms.Guna2Button();
            this.labelNotregistered = new System.Windows.Forms.Label();
            this.linkLabelSignUp = new System.Windows.Forms.LinkLabel();
            this.labelWrongUP = new System.Windows.Forms.Label();
            this.pBoxPassword = new System.Windows.Forms.PictureBox();
            this.textPassword = new Guna.UI2.WinForms.Guna2TextBox();
            this.pBoxUsername = new System.Windows.Forms.PictureBox();
            this.labelLogin = new System.Windows.Forms.Label();
            this.textUsername = new Guna.UI2.WinForms.Guna2TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.status1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.status2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.panelLogin.SuspendLayout();
            this.panelTitleBar.SuspendLayout();
            this.panelLogin2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxPassword)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxUsername)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLogin
            // 
            this.panelLogin.BackColor = System.Drawing.Color.White;
            this.panelLogin.Controls.Add(this.statusStrip1);
            this.panelLogin.Controls.Add(this.panelTitleBar);
            this.panelLogin.Controls.Add(this.panelLogin2);
            this.panelLogin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelLogin.Location = new System.Drawing.Point(0, 0);
            this.panelLogin.Name = "panelLogin";
            this.panelLogin.Size = new System.Drawing.Size(1264, 681);
            this.panelLogin.TabIndex = 0;
            // 
            // panelTitleBar
            // 
            this.panelTitleBar.BackColor = System.Drawing.Color.Transparent;
            this.panelTitleBar.Controls.Add(this.btnMinimise);
            this.panelTitleBar.Controls.Add(this.btnAppClose);
            this.panelTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitleBar.Location = new System.Drawing.Point(0, 0);
            this.panelTitleBar.Name = "panelTitleBar";
            this.panelTitleBar.Size = new System.Drawing.Size(1264, 57);
            this.panelTitleBar.TabIndex = 23;
            this.panelTitleBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelTitleBar_MouseDown);
            // 
            // btnMinimise
            // 
            this.btnMinimise.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimise.BackColor = System.Drawing.Color.Transparent;
            this.btnMinimise.FlatAppearance.BorderSize = 0;
            this.btnMinimise.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimise.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinimise.ForeColor = System.Drawing.Color.White;
            this.btnMinimise.Location = new System.Drawing.Point(1210, 0);
            this.btnMinimise.Name = "btnMinimise";
            this.btnMinimise.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.btnMinimise.Size = new System.Drawing.Size(27, 39);
            this.btnMinimise.TabIndex = 22;
            this.btnMinimise.Text = "-";
            this.btnMinimise.UseVisualStyleBackColor = false;
            this.btnMinimise.Click += new System.EventHandler(this.btnMinimise_Click);
            // 
            // btnAppClose
            // 
            this.btnAppClose.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAppClose.BackColor = System.Drawing.Color.Transparent;
            this.btnAppClose.FlatAppearance.BorderSize = 0;
            this.btnAppClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAppClose.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAppClose.ForeColor = System.Drawing.Color.White;
            this.btnAppClose.Location = new System.Drawing.Point(1236, 0);
            this.btnAppClose.Name = "btnAppClose";
            this.btnAppClose.Size = new System.Drawing.Size(27, 39);
            this.btnAppClose.TabIndex = 21;
            this.btnAppClose.Text = "x";
            this.btnAppClose.UseVisualStyleBackColor = false;
            this.btnAppClose.Click += new System.EventHandler(this.btnAppClose_Click);
            // 
            // panelLogin2
            // 
            this.panelLogin2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelLogin2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelLogin2.Controls.Add(this.cbtnShowPass);
            this.panelLogin2.Controls.Add(this.panel2);
            this.panelLogin2.Controls.Add(this.panel1);
            this.panelLogin2.Controls.Add(this.btnLogIn);
            this.panelLogin2.Controls.Add(this.labelNotregistered);
            this.panelLogin2.Controls.Add(this.linkLabelSignUp);
            this.panelLogin2.Controls.Add(this.labelWrongUP);
            this.panelLogin2.Controls.Add(this.pBoxPassword);
            this.panelLogin2.Controls.Add(this.textPassword);
            this.panelLogin2.Controls.Add(this.pBoxUsername);
            this.panelLogin2.Controls.Add(this.labelLogin);
            this.panelLogin2.Controls.Add(this.textUsername);
            this.panelLogin2.Location = new System.Drawing.Point(427, 135);
            this.panelLogin2.Name = "panelLogin2";
            this.panelLogin2.Size = new System.Drawing.Size(394, 387);
            this.panelLogin2.TabIndex = 20;
            // 
            // cbtnShowPass
            // 
            this.cbtnShowPass.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbtnShowPass.BackColor = System.Drawing.Color.White;
            this.cbtnShowPass.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cbtnShowPass.BorderColor = System.Drawing.Color.White;
            this.cbtnShowPass.CheckedState.Parent = this.cbtnShowPass;
            this.cbtnShowPass.CustomImages.Parent = this.cbtnShowPass;
            this.cbtnShowPass.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.cbtnShowPass.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.cbtnShowPass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.cbtnShowPass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.cbtnShowPass.DisabledState.Parent = this.cbtnShowPass;
            this.cbtnShowPass.FillColor = System.Drawing.Color.White;
            this.cbtnShowPass.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cbtnShowPass.ForeColor = System.Drawing.Color.White;
            this.cbtnShowPass.HoverState.Parent = this.cbtnShowPass;
            this.cbtnShowPass.Image = global::Transport_beta.Properties.Resources.hide;
            this.cbtnShowPass.Location = new System.Drawing.Point(291, 183);
            this.cbtnShowPass.Name = "cbtnShowPass";
            this.cbtnShowPass.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.cbtnShowPass.ShadowDecoration.Parent = this.cbtnShowPass;
            this.cbtnShowPass.Size = new System.Drawing.Size(26, 30);
            this.cbtnShowPass.TabIndex = 31;
            this.cbtnShowPass.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cbtnShowPass_MouseDown);
            this.cbtnShowPass.MouseUp += new System.Windows.Forms.MouseEventHandler(this.cbtnShowPass_MouseUp);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(61, 214);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(259, 2);
            this.panel2.TabIndex = 30;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(61, 154);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(257, 2);
            this.panel1.TabIndex = 29;
            // 
            // btnLogIn
            // 
            this.btnLogIn.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLogIn.BackColor = System.Drawing.Color.Transparent;
            this.btnLogIn.BorderRadius = 24;
            this.btnLogIn.CheckedState.Parent = this.btnLogIn;
            this.btnLogIn.CustomImages.Parent = this.btnLogIn;
            this.btnLogIn.DisabledState.Parent = this.btnLogIn;
            this.btnLogIn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnLogIn.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogIn.ForeColor = System.Drawing.Color.White;
            this.btnLogIn.HoverState.Parent = this.btnLogIn;
            this.btnLogIn.Location = new System.Drawing.Point(142, 272);
            this.btnLogIn.Name = "btnLogIn";
            this.btnLogIn.ShadowDecoration.Parent = this.btnLogIn;
            this.btnLogIn.Size = new System.Drawing.Size(94, 45);
            this.btnLogIn.TabIndex = 28;
            this.btnLogIn.Text = "Log In";
            this.btnLogIn.Click += new System.EventHandler(this.btnLogIn_Click);
            // 
            // labelNotregistered
            // 
            this.labelNotregistered.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelNotregistered.AutoSize = true;
            this.labelNotregistered.BackColor = System.Drawing.Color.Transparent;
            this.labelNotregistered.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNotregistered.Location = new System.Drawing.Point(102, 330);
            this.labelNotregistered.Name = "labelNotregistered";
            this.labelNotregistered.Size = new System.Drawing.Size(121, 16);
            this.labelNotregistered.TabIndex = 27;
            this.labelNotregistered.Text = "Not registered yet?";
            // 
            // linkLabelSignUp
            // 
            this.linkLabelSignUp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.linkLabelSignUp.AutoSize = true;
            this.linkLabelSignUp.BackColor = System.Drawing.Color.Transparent;
            this.linkLabelSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelSignUp.Location = new System.Drawing.Point(223, 330);
            this.linkLabelSignUp.Name = "linkLabelSignUp";
            this.linkLabelSignUp.Size = new System.Drawing.Size(56, 16);
            this.linkLabelSignUp.TabIndex = 26;
            this.linkLabelSignUp.TabStop = true;
            this.linkLabelSignUp.Text = "Sign Up";
            this.linkLabelSignUp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelSignUp_LinkClicked);
            // 
            // labelWrongUP
            // 
            this.labelWrongUP.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelWrongUP.AutoSize = true;
            this.labelWrongUP.BackColor = System.Drawing.Color.Transparent;
            this.labelWrongUP.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWrongUP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelWrongUP.Location = new System.Drawing.Point(85, 229);
            this.labelWrongUP.Name = "labelWrongUP";
            this.labelWrongUP.Size = new System.Drawing.Size(200, 17);
            this.labelWrongUP.TabIndex = 25;
            this.labelWrongUP.Text = "*Wrong Username or Password";
            this.labelWrongUP.Visible = false;
            // 
            // pBoxPassword
            // 
            this.pBoxPassword.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pBoxPassword.BackColor = System.Drawing.Color.Transparent;
            this.pBoxPassword.Image = global::Transport_beta.Properties.Resources.lock_25px;
            this.pBoxPassword.Location = new System.Drawing.Point(62, 184);
            this.pBoxPassword.Name = "pBoxPassword";
            this.pBoxPassword.Size = new System.Drawing.Size(25, 25);
            this.pBoxPassword.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pBoxPassword.TabIndex = 24;
            this.pBoxPassword.TabStop = false;
            // 
            // textPassword
            // 
            this.textPassword.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textPassword.BackColor = System.Drawing.Color.Transparent;
            this.textPassword.BorderRadius = 10;
            this.textPassword.BorderThickness = 0;
            this.textPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textPassword.DefaultText = "";
            this.textPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textPassword.DisabledState.Parent = this.textPassword;
            this.textPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textPassword.FocusedState.Parent = this.textPassword;
            this.textPassword.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textPassword.ForeColor = System.Drawing.Color.Black;
            this.textPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textPassword.HoverState.Parent = this.textPassword;
            this.textPassword.Location = new System.Drawing.Point(90, 176);
            this.textPassword.Margin = new System.Windows.Forms.Padding(4);
            this.textPassword.Name = "textPassword";
            this.textPassword.PasswordChar = '•';
            this.textPassword.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textPassword.PlaceholderText = "Password";
            this.textPassword.SelectedText = "";
            this.textPassword.ShadowDecoration.Parent = this.textPassword;
            this.textPassword.Size = new System.Drawing.Size(232, 37);
            this.textPassword.TabIndex = 23;
            // 
            // pBoxUsername
            // 
            this.pBoxUsername.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pBoxUsername.BackColor = System.Drawing.Color.Transparent;
            this.pBoxUsername.Image = global::Transport_beta.Properties.Resources.user_25px;
            this.pBoxUsername.Location = new System.Drawing.Point(61, 123);
            this.pBoxUsername.Name = "pBoxUsername";
            this.pBoxUsername.Size = new System.Drawing.Size(25, 25);
            this.pBoxUsername.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pBoxUsername.TabIndex = 22;
            this.pBoxUsername.TabStop = false;
            // 
            // labelLogin
            // 
            this.labelLogin.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelLogin.AutoSize = true;
            this.labelLogin.BackColor = System.Drawing.Color.Transparent;
            this.labelLogin.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLogin.Location = new System.Drawing.Point(114, 41);
            this.labelLogin.Name = "labelLogin";
            this.labelLogin.Size = new System.Drawing.Size(150, 32);
            this.labelLogin.TabIndex = 21;
            this.labelLogin.Text = "User Login";
            // 
            // textUsername
            // 
            this.textUsername.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textUsername.BackColor = System.Drawing.Color.Transparent;
            this.textUsername.BorderRadius = 10;
            this.textUsername.BorderThickness = 0;
            this.textUsername.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textUsername.DefaultText = "";
            this.textUsername.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textUsername.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textUsername.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textUsername.DisabledState.Parent = this.textUsername;
            this.textUsername.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textUsername.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textUsername.FocusedState.Parent = this.textUsername;
            this.textUsername.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.textUsername.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textUsername.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textUsername.HoverState.Parent = this.textUsername;
            this.textUsername.Location = new System.Drawing.Point(88, 116);
            this.textUsername.Margin = new System.Windows.Forms.Padding(4);
            this.textUsername.Name = "textUsername";
            this.textUsername.PasswordChar = '\0';
            this.textUsername.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textUsername.PlaceholderText = "Username";
            this.textUsername.SelectedText = "";
            this.textUsername.ShadowDecoration.Parent = this.textUsername;
            this.textUsername.Size = new System.Drawing.Size(232, 37);
            this.textUsername.TabIndex = 20;
            this.textUsername.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textUsername_KeyDown);
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.DarkGray;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.status1,
            this.status2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 659);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1264, 22);
            this.statusStrip1.TabIndex = 24;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // status1
            // 
            this.status1.Name = "status1";
            this.status1.Size = new System.Drawing.Size(75, 17);
            this.status1.Text = "App is ready!";
            // 
            // status2
            // 
            this.status2.Name = "status2";
            this.status2.Size = new System.Drawing.Size(0, 17);
            // 
            // FormLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Transport_beta.Properties.Resources.MicrosoftTeams_image;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.panelLogin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimizeBox = false;
            this.Name = "FormLogin";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panelLogin.ResumeLayout(false);
            this.panelLogin.PerformLayout();
            this.panelTitleBar.ResumeLayout(false);
            this.panelLogin2.ResumeLayout(false);
            this.panelLogin2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxPassword)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxUsername)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLogin;
        private System.Windows.Forms.Panel panelLogin2;
        private Guna.UI2.WinForms.Guna2CircleButton cbtnShowPass;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2Button btnLogIn;
        private System.Windows.Forms.Label labelNotregistered;
        private System.Windows.Forms.LinkLabel linkLabelSignUp;
        private System.Windows.Forms.Label labelWrongUP;
        private System.Windows.Forms.PictureBox pBoxPassword;
        private Guna.UI2.WinForms.Guna2TextBox textPassword;
        private System.Windows.Forms.PictureBox pBoxUsername;
        private System.Windows.Forms.Label labelLogin;
        private Guna.UI2.WinForms.Guna2TextBox textUsername;
        private System.Windows.Forms.Button btnMinimise;
        private System.Windows.Forms.Button btnAppClose;
        private System.Windows.Forms.Panel panelTitleBar;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel status1;
        private System.Windows.Forms.ToolStripStatusLabel status2;
    }
}

