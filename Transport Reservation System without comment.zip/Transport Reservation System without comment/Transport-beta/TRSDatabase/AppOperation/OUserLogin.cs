﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TRSDatabase.AppInfo;

namespace TRSDatabase.AppConnect
{
    public class OUserLogin
    {
        SqlConnection DBconnect = new SqlConnection("Data Source=DESKTOP-H84DT5K;Initial Catalog=TRSalpha;Integrated Security=True");

        public int SearchUser(InfoUserLogin i)
        {
            string query = "Select * from UserLogin where Username ='" + i.Username + "';" +
                "Select * from UserLogin where Username ='" + i.Username + "' and Password = '" + i.Password + "'";
            
            DBconnect.Open();
            SqlCommand cmd0 = new SqlCommand(query, DBconnect);
            SqlDataReader sdr0 = cmd0.ExecuteReader();
            
            if (sdr0.HasRows)
            {
                sdr0.NextResult();

                if (sdr0.HasRows)
                {
                    DBconnect.Close();
                    return 0;
                }
                else
                {
                    DBconnect.Close(); 
                    return 1;
                }
            }
            else
            {
                DBconnect.Close();
                return 2;
            }
        }

        public string checkUser(string Username)
        {
            DBconnect.Open();
            SqlCommand cmd0 = new SqlCommand("Select * from UserInfo where Username ='" + Username + "' AND Role='Admin'", DBconnect);
            SqlDataReader sdr0 = cmd0.ExecuteReader();

            if (sdr0.HasRows)
            {
                DBconnect.Close();
                return "Admin";
            }
            else
            {
                DBconnect.Close();
                return "Customer";
            }
        }
    }
}