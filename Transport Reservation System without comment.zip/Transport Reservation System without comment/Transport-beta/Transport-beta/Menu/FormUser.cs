﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TRSDatabase.AppConnect;
using TRSDatabase.AppInfo;

namespace Transport_beta.Menu
{
    public partial class FormUser : Form
    {
        public FormUser()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            InfoUser Iu = new InfoUser();
            OCAccount Ou = new OCAccount();
            Iu.Fname = textFirstName.Text;
            Iu.Lname = textLastName.Text;
            Iu.NidNo = textNID.Text;
            Iu.Email = textEmail.Text;
            Iu.PhoneNo = textPhone.Text;
            Iu.Address = textAddress.Text;
            Iu.Username = textUsername.Text.ToLower();
            Iu.Password = textPassword.Text;
            Iu.Role = cboxRole.Text;

            if (FormLogin.check(Iu.Fname,Iu.Lname,Iu.NidNo,Iu.Email,Iu.PhoneNo,Iu.Address,Iu.Password,Iu.Role, Iu.Username)
                                           || (!rbtnMale.Checked && !rbtnFemale.Checked && !rbtnOther.Checked))
            {
                labelFillall.Visible = true;
                return;
            }

            //Gender Button
            RadioButton rb = panelUser.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Checked);
            Iu.Gender = rb.Text;

            //Date of Birth 
            DateTime BirthDate = DBirth.Value;
            TimeSpan timeSpan = DateTime.Now - BirthDate;
            int Age = (int)(timeSpan.TotalDays / 365); //.ToString("0");
            if (Age < 10)
            {
                MessageBox.Show("User must be minimum 10 years old");
                labelFillall.Visible = true;
                return;
            }
            Iu.Dob = BirthDate;

            try
            {
                int flag = Ou.Add(Iu);
                if (flag > 0)
                {
                    labelFillall.Visible = false;
                    RefDataGrid();
                    MessageBox.Show("Account has been added!");
                }
                else if (flag == 2)
                {
                    MessageBox.Show("Username already exists!"); ;
                }
                else MessageBox.Show("Error in adding account!");
            }
            catch (Exception exc) { MessageBox.Show(exc.ToString()); }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            InfoUser Iu = new InfoUser();
            OCAccount Ou = new OCAccount();
            Iu.Fname = textFirstName.Text;
            Iu.Lname = textLastName.Text;
            Iu.NidNo = textNID.Text;
            Iu.Email = textEmail.Text;
            Iu.PhoneNo = textPhone.Text;
            Iu.Address = textAddress.Text;
            Iu.Username = textUsername.Text.ToLower();
            Iu.Password = textPassword.Text;
            Iu.Role = cboxRole.Text;

            if (FormLogin.check(Iu.Fname, Iu.Lname, Iu.NidNo, Iu.Email, Iu.PhoneNo, Iu.Address, Iu.Password, Iu.Role, Iu.Username)
                                           || (!rbtnMale.Checked && !rbtnFemale.Checked && !rbtnOther.Checked))
            {
                labelFillall.Visible = true;
                return;
            }

            //Gender Button
            RadioButton rb = panelUser.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Checked);
            Iu.Gender = rb.Text;

            //Date of Birth 
            DateTime BirthDate = DBirth.Value;
            TimeSpan timeSpan = DateTime.Now - BirthDate;
            int Age = (int)(timeSpan.TotalDays / 365); //.ToString("0");
            if (Age < 10)
            {
                MessageBox.Show("User must be minimum 10 years old");
                labelFillall.Visible = true;
                return;
            }
            Iu.Dob = BirthDate;

            try
            {
                int flag = Ou.Update(Iu);
                if (flag > 0)
                {
                    labelFillall.Visible = false;
                    RefDataGrid();
                    MessageBox.Show("Account has been updated!");
                }
                else if (flag == 0)
                {
                    MessageBox.Show("Account not found!"); ;
                }
                else
                {
                    MessageBox.Show("Error in updating account!");
                }
            }
            catch (Exception exc) { MessageBox.Show(exc.ToString()); }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            InfoUser Iu = new InfoUser();
            OCAccount Ou = new OCAccount();
            Iu.Username = textUsername.Text;
            Iu.Role = cboxRole.Text;

            if (FormLogin.check(Iu.Username, Iu.Role))
            {
                labelFillall.Visible = true;
                MessageBox.Show("Username and Role are required to delete");
                return;
            }
            if (Iu.Role == "Admin")
            {
                MessageBox.Show("Cannot delete the account of Admin.");
                return;
            }

            try
            {
                int flag = Ou.Delete(Iu);
                if (flag > 0)
                {
                    labelFillall.Visible = false;
                    RefDataGrid();
                    MessageBox.Show("Account has been deleted!");
                }
                else MessageBox.Show("Username is not found!");
            }
            catch (Exception exc) { MessageBox.Show(exc.ToString()); }
        }

        private void FormUser_Load(object sender, EventArgs e)
        {
            DBirth.Value = DateTime.Today;
            RefDataGrid();
        }

        private void RefDataGrid()
        {
            SqlDataAdapter sqlda = new OCAccount().ShowUsers();
            DataTable dt = new DataTable();
            sqlda.Fill(dt);
            dataGridUser.DataSource = dt;
        }

        private void textPassword_Click(object sender, EventArgs e)
        {
            cbtnShowPass.Visible = true;
        }

        private void cbtnShowPass_MouseDown(object sender, MouseEventArgs e)
        {
            textPassword.PasswordChar = '\0';
            cbtnShowPass.Image = Properties.Resources.show;
        }

        private void cbtnShowPass_MouseUp(object sender, MouseEventArgs e)
        {
            textPassword.PasswordChar = '•';
            cbtnShowPass.Image = Properties.Resources.hide;
        }

        private void dataGridUser_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textFirstName.Text = dataGridUser.SelectedRows[0].Cells[3].Value.ToString();
            textLastName.Text = dataGridUser.SelectedRows[0].Cells[4].Value.ToString();
            textNID.Text = dataGridUser.SelectedRows[0].Cells[5].Value.ToString();
            textEmail.Text = dataGridUser.SelectedRows[0].Cells[6].Value.ToString();
            textPhone.Text = dataGridUser.SelectedRows[0].Cells[7].Value.ToString();
            textAddress.Text = dataGridUser.SelectedRows[0].Cells[8].Value.ToString();
            textUsername.Text = dataGridUser.SelectedRows[0].Cells[0].Value.ToString();
            textPassword.Text = dataGridUser.SelectedRows[0].Cells[1].Value.ToString();
            cboxRole.Text = dataGridUser.SelectedRows[0].Cells[2].Value.ToString();
            DBirth.Value = (DateTime)dataGridUser.SelectedRows[0].Cells[10].Value;
            string Gender = dataGridUser.SelectedRows[0].Cells[9].Value.ToString();
            RadioButton rb = panelUser.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Text==Gender);
            rb.Checked = true;
        }
    }
}
