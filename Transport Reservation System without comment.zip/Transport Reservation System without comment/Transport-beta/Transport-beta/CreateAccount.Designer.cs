﻿
namespace Transport_beta
{
    partial class FormCreateAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelSignupBg = new System.Windows.Forms.Panel();
            this.btnMinimise = new System.Windows.Forms.Button();
            this.btnAppClose = new System.Windows.Forms.Button();
            this.panelSignup = new System.Windows.Forms.Panel();
            this.labelNotregistered = new System.Windows.Forms.Label();
            this.linkLabelLogin = new System.Windows.Forms.LinkLabel();
            this.labelFillall = new System.Windows.Forms.Label();
            this.DBirth = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.cbtnConfirmPass = new Guna.UI2.WinForms.Guna2CircleButton();
            this.textConfirmpass = new Guna.UI2.WinForms.Guna2TextBox();
            this.labelDob = new System.Windows.Forms.Label();
            this.rbtnOther = new System.Windows.Forms.RadioButton();
            this.rbtnFemale = new System.Windows.Forms.RadioButton();
            this.labelGender = new System.Windows.Forms.Label();
            this.rbtnMale = new System.Windows.Forms.RadioButton();
            this.textNID = new Guna.UI2.WinForms.Guna2TextBox();
            this.textAddress = new Guna.UI2.WinForms.Guna2TextBox();
            this.textPhone = new Guna.UI2.WinForms.Guna2TextBox();
            this.textEmail = new Guna.UI2.WinForms.Guna2TextBox();
            this.textLastName = new Guna.UI2.WinForms.Guna2TextBox();
            this.textFirstName = new Guna.UI2.WinForms.Guna2TextBox();
            this.cbtnSignShowPass = new Guna.UI2.WinForms.Guna2CircleButton();
            this.btnSignup = new Guna.UI2.WinForms.Guna2Button();
            this.labelConfirmPass = new System.Windows.Forms.Label();
            this.textSignPassword = new Guna.UI2.WinForms.Guna2TextBox();
            this.labelSignUp = new System.Windows.Forms.Label();
            this.textSignUsername = new Guna.UI2.WinForms.Guna2TextBox();
            this.panelSignupBg.SuspendLayout();
            this.panelSignup.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSignupBg
            // 
            this.panelSignupBg.BackColor = System.Drawing.Color.White;
            this.panelSignupBg.Controls.Add(this.btnMinimise);
            this.panelSignupBg.Controls.Add(this.btnAppClose);
            this.panelSignupBg.Controls.Add(this.panelSignup);
            this.panelSignupBg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelSignupBg.Location = new System.Drawing.Point(0, 0);
            this.panelSignupBg.Name = "panelSignupBg";
            this.panelSignupBg.Size = new System.Drawing.Size(1264, 681);
            this.panelSignupBg.TabIndex = 1;
            // 
            // btnMinimise
            // 
            this.btnMinimise.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimise.BackColor = System.Drawing.Color.Transparent;
            this.btnMinimise.FlatAppearance.BorderSize = 0;
            this.btnMinimise.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimise.Font = new System.Drawing.Font("Unispace", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinimise.ForeColor = System.Drawing.Color.White;
            this.btnMinimise.Location = new System.Drawing.Point(1210, 0);
            this.btnMinimise.Name = "btnMinimise";
            this.btnMinimise.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.btnMinimise.Size = new System.Drawing.Size(27, 39);
            this.btnMinimise.TabIndex = 27;
            this.btnMinimise.Text = "-";
            this.btnMinimise.UseVisualStyleBackColor = false;
            this.btnMinimise.Click += new System.EventHandler(this.btnMinimise_Click);
            // 
            // btnAppClose
            // 
            this.btnAppClose.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAppClose.BackColor = System.Drawing.Color.Transparent;
            this.btnAppClose.FlatAppearance.BorderSize = 0;
            this.btnAppClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAppClose.Font = new System.Drawing.Font("Comic Sans MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAppClose.ForeColor = System.Drawing.Color.White;
            this.btnAppClose.Location = new System.Drawing.Point(1236, 0);
            this.btnAppClose.Name = "btnAppClose";
            this.btnAppClose.Size = new System.Drawing.Size(27, 39);
            this.btnAppClose.TabIndex = 26;
            this.btnAppClose.Text = "x";
            this.btnAppClose.UseVisualStyleBackColor = false;
            this.btnAppClose.Click += new System.EventHandler(this.btnAppClose_Click);
            // 
            // panelSignup
            // 
            this.panelSignup.BackColor = System.Drawing.Color.Transparent;
            this.panelSignup.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelSignup.Controls.Add(this.labelNotregistered);
            this.panelSignup.Controls.Add(this.linkLabelLogin);
            this.panelSignup.Controls.Add(this.labelFillall);
            this.panelSignup.Controls.Add(this.DBirth);
            this.panelSignup.Controls.Add(this.cbtnConfirmPass);
            this.panelSignup.Controls.Add(this.textConfirmpass);
            this.panelSignup.Controls.Add(this.labelDob);
            this.panelSignup.Controls.Add(this.rbtnOther);
            this.panelSignup.Controls.Add(this.rbtnFemale);
            this.panelSignup.Controls.Add(this.labelGender);
            this.panelSignup.Controls.Add(this.rbtnMale);
            this.panelSignup.Controls.Add(this.textNID);
            this.panelSignup.Controls.Add(this.textAddress);
            this.panelSignup.Controls.Add(this.textPhone);
            this.panelSignup.Controls.Add(this.textEmail);
            this.panelSignup.Controls.Add(this.textLastName);
            this.panelSignup.Controls.Add(this.textFirstName);
            this.panelSignup.Controls.Add(this.cbtnSignShowPass);
            this.panelSignup.Controls.Add(this.btnSignup);
            this.panelSignup.Controls.Add(this.labelConfirmPass);
            this.panelSignup.Controls.Add(this.textSignPassword);
            this.panelSignup.Controls.Add(this.labelSignUp);
            this.panelSignup.Controls.Add(this.textSignUsername);
            this.panelSignup.Location = new System.Drawing.Point(410, 27);
            this.panelSignup.Name = "panelSignup";
            this.panelSignup.Size = new System.Drawing.Size(442, 642);
            this.panelSignup.TabIndex = 15;
            // 
            // labelNotregistered
            // 
            this.labelNotregistered.AutoSize = true;
            this.labelNotregistered.BackColor = System.Drawing.Color.Transparent;
            this.labelNotregistered.Font = new System.Drawing.Font("Bahnschrift SemiLight", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNotregistered.Location = new System.Drawing.Point(115, 616);
            this.labelNotregistered.Name = "labelNotregistered";
            this.labelNotregistered.Size = new System.Drawing.Size(137, 16);
            this.labelNotregistered.TabIndex = 56;
            this.labelNotregistered.Text = "Already have account?";
            // 
            // linkLabelLogin
            // 
            this.linkLabelLogin.AutoSize = true;
            this.linkLabelLogin.BackColor = System.Drawing.Color.Transparent;
            this.linkLabelLogin.Font = new System.Drawing.Font("Bahnschrift SemiLight", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelLogin.Location = new System.Drawing.Point(258, 616);
            this.linkLabelLogin.Name = "linkLabelLogin";
            this.linkLabelLogin.Size = new System.Drawing.Size(43, 16);
            this.linkLabelLogin.TabIndex = 55;
            this.linkLabelLogin.TabStop = true;
            this.linkLabelLogin.Text = "Log In";
            this.linkLabelLogin.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelLogin_LinkClicked);
            // 
            // labelFillall
            // 
            this.labelFillall.AutoSize = true;
            this.labelFillall.BackColor = System.Drawing.Color.Transparent;
            this.labelFillall.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFillall.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelFillall.Location = new System.Drawing.Point(65, 541);
            this.labelFillall.Name = "labelFillall";
            this.labelFillall.Size = new System.Drawing.Size(130, 20);
            this.labelFillall.TabIndex = 54;
            this.labelFillall.Text = "*Fill all the details";
            this.labelFillall.Visible = false;
            // 
            // DBirth
            // 
            this.DBirth.BackColor = System.Drawing.Color.Transparent;
            this.DBirth.BorderRadius = 5;
            this.DBirth.CheckedState.Parent = this.DBirth;
            this.DBirth.FillColor = System.Drawing.Color.White;
            this.DBirth.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F);
            this.DBirth.ForeColor = System.Drawing.Color.Black;
            this.DBirth.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.DBirth.HoverState.Parent = this.DBirth;
            this.DBirth.Location = new System.Drawing.Point(191, 349);
            this.DBirth.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.DBirth.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.DBirth.Name = "DBirth";
            this.DBirth.ShadowDecoration.Parent = this.DBirth;
            this.DBirth.Size = new System.Drawing.Size(198, 34);
            this.DBirth.TabIndex = 36;
            this.DBirth.Value = new System.DateTime(2021, 7, 24, 13, 14, 7, 837);
            // 
            // cbtnConfirmPass
            // 
            this.cbtnConfirmPass.BackColor = System.Drawing.Color.White;
            this.cbtnConfirmPass.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cbtnConfirmPass.BorderColor = System.Drawing.Color.White;
            this.cbtnConfirmPass.CheckedState.Parent = this.cbtnConfirmPass;
            this.cbtnConfirmPass.CustomImages.Parent = this.cbtnConfirmPass;
            this.cbtnConfirmPass.DefaultAutoSize = true;
            this.cbtnConfirmPass.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.cbtnConfirmPass.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.cbtnConfirmPass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.cbtnConfirmPass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.cbtnConfirmPass.DisabledState.Parent = this.cbtnConfirmPass;
            this.cbtnConfirmPass.FillColor = System.Drawing.Color.White;
            this.cbtnConfirmPass.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cbtnConfirmPass.ForeColor = System.Drawing.Color.White;
            this.cbtnConfirmPass.HoverState.Parent = this.cbtnConfirmPass;
            this.cbtnConfirmPass.Image = global::Transport_beta.Properties.Resources.hide;
            this.cbtnConfirmPass.Location = new System.Drawing.Point(357, 483);
            this.cbtnConfirmPass.Name = "cbtnConfirmPass";
            this.cbtnConfirmPass.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.cbtnConfirmPass.ShadowDecoration.Parent = this.cbtnConfirmPass;
            this.cbtnConfirmPass.Size = new System.Drawing.Size(26, 30);
            this.cbtnConfirmPass.TabIndex = 53;
            this.cbtnConfirmPass.Visible = false;
            this.cbtnConfirmPass.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cbtnConfirmPass_MouseDown);
            this.cbtnConfirmPass.MouseUp += new System.Windows.Forms.MouseEventHandler(this.cbtnConfirmPass_MouseUp);
            // 
            // textConfirmpass
            // 
            this.textConfirmpass.BackColor = System.Drawing.Color.Transparent;
            this.textConfirmpass.BorderRadius = 10;
            this.textConfirmpass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textConfirmpass.DefaultText = "";
            this.textConfirmpass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textConfirmpass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textConfirmpass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textConfirmpass.DisabledState.Parent = this.textConfirmpass;
            this.textConfirmpass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textConfirmpass.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textConfirmpass.FocusedState.Parent = this.textConfirmpass;
            this.textConfirmpass.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textConfirmpass.ForeColor = System.Drawing.Color.Black;
            this.textConfirmpass.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textConfirmpass.HoverState.Parent = this.textConfirmpass;
            this.textConfirmpass.Location = new System.Drawing.Point(59, 480);
            this.textConfirmpass.Margin = new System.Windows.Forms.Padding(4);
            this.textConfirmpass.Name = "textConfirmpass";
            this.textConfirmpass.PasswordChar = '•';
            this.textConfirmpass.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textConfirmpass.PlaceholderText = "Confirm Password*";
            this.textConfirmpass.SelectedText = "";
            this.textConfirmpass.ShadowDecoration.Parent = this.textConfirmpass;
            this.textConfirmpass.Size = new System.Drawing.Size(330, 37);
            this.textConfirmpass.TabIndex = 52;
            this.textConfirmpass.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textConfirmpass_MouseClick);
            this.textConfirmpass.MouseLeave += new System.EventHandler(this.textConfirmpass_MouseLeave);
            // 
            // labelDob
            // 
            this.labelDob.AutoSize = true;
            this.labelDob.BackColor = System.Drawing.Color.Transparent;
            this.labelDob.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDob.Location = new System.Drawing.Point(63, 356);
            this.labelDob.Name = "labelDob";
            this.labelDob.Size = new System.Drawing.Size(122, 20);
            this.labelDob.TabIndex = 51;
            this.labelDob.Text = "Date of Birth* :";
            // 
            // rbtnOther
            // 
            this.rbtnOther.AutoSize = true;
            this.rbtnOther.BackColor = System.Drawing.Color.Transparent;
            this.rbtnOther.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnOther.Location = new System.Drawing.Point(314, 315);
            this.rbtnOther.Name = "rbtnOther";
            this.rbtnOther.Size = new System.Drawing.Size(68, 24);
            this.rbtnOther.TabIndex = 50;
            this.rbtnOther.TabStop = true;
            this.rbtnOther.Text = "Other";
            this.rbtnOther.UseVisualStyleBackColor = false;
            // 
            // rbtnFemale
            // 
            this.rbtnFemale.AutoSize = true;
            this.rbtnFemale.BackColor = System.Drawing.Color.Transparent;
            this.rbtnFemale.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnFemale.Location = new System.Drawing.Point(229, 315);
            this.rbtnFemale.Name = "rbtnFemale";
            this.rbtnFemale.Size = new System.Drawing.Size(79, 24);
            this.rbtnFemale.TabIndex = 49;
            this.rbtnFemale.TabStop = true;
            this.rbtnFemale.Text = "Female";
            this.rbtnFemale.UseVisualStyleBackColor = false;
            // 
            // labelGender
            // 
            this.labelGender.AutoSize = true;
            this.labelGender.BackColor = System.Drawing.Color.Transparent;
            this.labelGender.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGender.Location = new System.Drawing.Point(63, 316);
            this.labelGender.Name = "labelGender";
            this.labelGender.Size = new System.Drawing.Size(85, 20);
            this.labelGender.TabIndex = 48;
            this.labelGender.Text = "Gender*  :";
            // 
            // rbtnMale
            // 
            this.rbtnMale.AutoSize = true;
            this.rbtnMale.BackColor = System.Drawing.Color.Transparent;
            this.rbtnMale.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnMale.Location = new System.Drawing.Point(160, 315);
            this.rbtnMale.Name = "rbtnMale";
            this.rbtnMale.Size = new System.Drawing.Size(63, 24);
            this.rbtnMale.TabIndex = 47;
            this.rbtnMale.TabStop = true;
            this.rbtnMale.Text = "Male";
            this.rbtnMale.UseVisualStyleBackColor = false;
            // 
            // textNID
            // 
            this.textNID.AcceptsReturn = true;
            this.textNID.BackColor = System.Drawing.Color.Transparent;
            this.textNID.BorderRadius = 10;
            this.textNID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textNID.DefaultText = "";
            this.textNID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textNID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textNID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textNID.DisabledState.Parent = this.textNID;
            this.textNID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textNID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textNID.FocusedState.Parent = this.textNID;
            this.textNID.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textNID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textNID.HoverState.Parent = this.textNID;
            this.textNID.Location = new System.Drawing.Point(59, 103);
            this.textNID.Margin = new System.Windows.Forms.Padding(4);
            this.textNID.Name = "textNID";
            this.textNID.PasswordChar = '\0';
            this.textNID.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textNID.PlaceholderText = "NID Number";
            this.textNID.SelectedText = "";
            this.textNID.ShadowDecoration.Parent = this.textNID;
            this.textNID.Size = new System.Drawing.Size(330, 37);
            this.textNID.TabIndex = 46;
            // 
            // textAddress
            // 
            this.textAddress.AcceptsReturn = true;
            this.textAddress.BackColor = System.Drawing.Color.Transparent;
            this.textAddress.BorderRadius = 10;
            this.textAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textAddress.DefaultText = "";
            this.textAddress.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textAddress.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textAddress.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textAddress.DisabledState.Parent = this.textAddress;
            this.textAddress.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textAddress.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textAddress.FocusedState.Parent = this.textAddress;
            this.textAddress.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.textAddress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textAddress.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textAddress.HoverState.Parent = this.textAddress;
            this.textAddress.Location = new System.Drawing.Point(59, 238);
            this.textAddress.Margin = new System.Windows.Forms.Padding(4);
            this.textAddress.Multiline = true;
            this.textAddress.Name = "textAddress";
            this.textAddress.PasswordChar = '\0';
            this.textAddress.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textAddress.PlaceholderText = "Address*";
            this.textAddress.SelectedText = "";
            this.textAddress.ShadowDecoration.Parent = this.textAddress;
            this.textAddress.Size = new System.Drawing.Size(330, 64);
            this.textAddress.TabIndex = 45;
            // 
            // textPhone
            // 
            this.textPhone.AcceptsReturn = true;
            this.textPhone.BackColor = System.Drawing.Color.Transparent;
            this.textPhone.BorderRadius = 10;
            this.textPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textPhone.DefaultText = "";
            this.textPhone.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textPhone.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textPhone.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textPhone.DisabledState.Parent = this.textPhone;
            this.textPhone.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textPhone.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textPhone.FocusedState.Parent = this.textPhone;
            this.textPhone.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textPhone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textPhone.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textPhone.HoverState.Parent = this.textPhone;
            this.textPhone.Location = new System.Drawing.Point(59, 193);
            this.textPhone.Margin = new System.Windows.Forms.Padding(4);
            this.textPhone.Name = "textPhone";
            this.textPhone.PasswordChar = '\0';
            this.textPhone.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textPhone.PlaceholderText = "Phone Number*";
            this.textPhone.SelectedText = "";
            this.textPhone.ShadowDecoration.Parent = this.textPhone;
            this.textPhone.Size = new System.Drawing.Size(330, 37);
            this.textPhone.TabIndex = 44;
            // 
            // textEmail
            // 
            this.textEmail.AcceptsReturn = true;
            this.textEmail.BackColor = System.Drawing.Color.Transparent;
            this.textEmail.BorderRadius = 10;
            this.textEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textEmail.DefaultText = "";
            this.textEmail.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textEmail.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textEmail.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textEmail.DisabledState.Parent = this.textEmail;
            this.textEmail.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textEmail.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textEmail.FocusedState.Parent = this.textEmail;
            this.textEmail.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textEmail.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textEmail.HoverState.Parent = this.textEmail;
            this.textEmail.Location = new System.Drawing.Point(59, 148);
            this.textEmail.Margin = new System.Windows.Forms.Padding(4);
            this.textEmail.Name = "textEmail";
            this.textEmail.PasswordChar = '\0';
            this.textEmail.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textEmail.PlaceholderText = "E-mail*";
            this.textEmail.SelectedText = "";
            this.textEmail.ShadowDecoration.Parent = this.textEmail;
            this.textEmail.Size = new System.Drawing.Size(330, 37);
            this.textEmail.TabIndex = 43;
            // 
            // textLastName
            // 
            this.textLastName.AcceptsReturn = true;
            this.textLastName.BackColor = System.Drawing.Color.Transparent;
            this.textLastName.BorderRadius = 10;
            this.textLastName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textLastName.DefaultText = "";
            this.textLastName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textLastName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textLastName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textLastName.DisabledState.Parent = this.textLastName;
            this.textLastName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textLastName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textLastName.FocusedState.Parent = this.textLastName;
            this.textLastName.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textLastName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textLastName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textLastName.HoverState.Parent = this.textLastName;
            this.textLastName.Location = new System.Drawing.Point(228, 58);
            this.textLastName.Margin = new System.Windows.Forms.Padding(4);
            this.textLastName.Name = "textLastName";
            this.textLastName.PasswordChar = '\0';
            this.textLastName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textLastName.PlaceholderText = "Last Name*";
            this.textLastName.SelectedText = "";
            this.textLastName.ShadowDecoration.Parent = this.textLastName;
            this.textLastName.Size = new System.Drawing.Size(161, 37);
            this.textLastName.TabIndex = 42;
            // 
            // textFirstName
            // 
            this.textFirstName.AcceptsReturn = true;
            this.textFirstName.BackColor = System.Drawing.Color.Transparent;
            this.textFirstName.BorderRadius = 10;
            this.textFirstName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textFirstName.DefaultText = "";
            this.textFirstName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textFirstName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textFirstName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textFirstName.DisabledState.Parent = this.textFirstName;
            this.textFirstName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textFirstName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textFirstName.FocusedState.Parent = this.textFirstName;
            this.textFirstName.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textFirstName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textFirstName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textFirstName.HoverState.Parent = this.textFirstName;
            this.textFirstName.Location = new System.Drawing.Point(59, 58);
            this.textFirstName.Margin = new System.Windows.Forms.Padding(4);
            this.textFirstName.Name = "textFirstName";
            this.textFirstName.PasswordChar = '\0';
            this.textFirstName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textFirstName.PlaceholderText = "First Name*";
            this.textFirstName.SelectedText = "";
            this.textFirstName.ShadowDecoration.Parent = this.textFirstName;
            this.textFirstName.Size = new System.Drawing.Size(161, 37);
            this.textFirstName.TabIndex = 41;
            // 
            // cbtnSignShowPass
            // 
            this.cbtnSignShowPass.BackColor = System.Drawing.Color.White;
            this.cbtnSignShowPass.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cbtnSignShowPass.BorderColor = System.Drawing.Color.White;
            this.cbtnSignShowPass.CheckedState.Parent = this.cbtnSignShowPass;
            this.cbtnSignShowPass.CustomImages.Parent = this.cbtnSignShowPass;
            this.cbtnSignShowPass.DefaultAutoSize = true;
            this.cbtnSignShowPass.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.cbtnSignShowPass.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.cbtnSignShowPass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.cbtnSignShowPass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.cbtnSignShowPass.DisabledState.Parent = this.cbtnSignShowPass;
            this.cbtnSignShowPass.FillColor = System.Drawing.Color.White;
            this.cbtnSignShowPass.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cbtnSignShowPass.ForeColor = System.Drawing.Color.White;
            this.cbtnSignShowPass.HoverState.Parent = this.cbtnSignShowPass;
            this.cbtnSignShowPass.Image = global::Transport_beta.Properties.Resources.hide;
            this.cbtnSignShowPass.Location = new System.Drawing.Point(358, 439);
            this.cbtnSignShowPass.Name = "cbtnSignShowPass";
            this.cbtnSignShowPass.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.cbtnSignShowPass.ShadowDecoration.Parent = this.cbtnSignShowPass;
            this.cbtnSignShowPass.Size = new System.Drawing.Size(26, 30);
            this.cbtnSignShowPass.TabIndex = 40;
            this.cbtnSignShowPass.Visible = false;
            this.cbtnSignShowPass.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cbtnSignShowPass_MouseDown);
            this.cbtnSignShowPass.MouseUp += new System.Windows.Forms.MouseEventHandler(this.cbtnSignShowPass_MouseUp);
            // 
            // btnSignup
            // 
            this.btnSignup.BackColor = System.Drawing.Color.Transparent;
            this.btnSignup.BorderRadius = 24;
            this.btnSignup.CheckedState.Parent = this.btnSignup;
            this.btnSignup.CustomImages.Parent = this.btnSignup;
            this.btnSignup.DisabledState.Parent = this.btnSignup;
            this.btnSignup.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnSignup.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignup.ForeColor = System.Drawing.Color.White;
            this.btnSignup.HoverState.Parent = this.btnSignup;
            this.btnSignup.Location = new System.Drawing.Point(160, 568);
            this.btnSignup.Name = "btnSignup";
            this.btnSignup.ShadowDecoration.Parent = this.btnSignup;
            this.btnSignup.Size = new System.Drawing.Size(100, 45);
            this.btnSignup.TabIndex = 39;
            this.btnSignup.Text = "Sign Up";
            this.btnSignup.Click += new System.EventHandler(this.btnSignup_Click);
            // 
            // labelConfirmPass
            // 
            this.labelConfirmPass.AutoSize = true;
            this.labelConfirmPass.BackColor = System.Drawing.Color.Transparent;
            this.labelConfirmPass.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelConfirmPass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelConfirmPass.Location = new System.Drawing.Point(65, 520);
            this.labelConfirmPass.Name = "labelConfirmPass";
            this.labelConfirmPass.Size = new System.Drawing.Size(175, 19);
            this.labelConfirmPass.TabIndex = 38;
            this.labelConfirmPass.Text = "*Password does not match";
            this.labelConfirmPass.Visible = false;
            // 
            // textSignPassword
            // 
            this.textSignPassword.BackColor = System.Drawing.Color.Transparent;
            this.textSignPassword.BorderRadius = 10;
            this.textSignPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textSignPassword.DefaultText = "";
            this.textSignPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textSignPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textSignPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textSignPassword.DisabledState.Parent = this.textSignPassword;
            this.textSignPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textSignPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textSignPassword.FocusedState.Parent = this.textSignPassword;
            this.textSignPassword.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSignPassword.ForeColor = System.Drawing.Color.Black;
            this.textSignPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textSignPassword.HoverState.Parent = this.textSignPassword;
            this.textSignPassword.Location = new System.Drawing.Point(59, 435);
            this.textSignPassword.Margin = new System.Windows.Forms.Padding(4);
            this.textSignPassword.Name = "textSignPassword";
            this.textSignPassword.PasswordChar = '•';
            this.textSignPassword.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textSignPassword.PlaceholderText = "Password*";
            this.textSignPassword.SelectedText = "";
            this.textSignPassword.ShadowDecoration.Parent = this.textSignPassword;
            this.textSignPassword.Size = new System.Drawing.Size(330, 37);
            this.textSignPassword.TabIndex = 37;
            this.textSignPassword.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textSignPassword_MouseClick);
            // 
            // labelSignUp
            // 
            this.labelSignUp.AutoSize = true;
            this.labelSignUp.BackColor = System.Drawing.Color.Transparent;
            this.labelSignUp.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSignUp.Location = new System.Drawing.Point(133, 9);
            this.labelSignUp.Name = "labelSignUp";
            this.labelSignUp.Size = new System.Drawing.Size(177, 32);
            this.labelSignUp.TabIndex = 35;
            this.labelSignUp.Text = "User Sign Up";
            // 
            // textSignUsername
            // 
            this.textSignUsername.AcceptsReturn = true;
            this.textSignUsername.BackColor = System.Drawing.Color.Transparent;
            this.textSignUsername.BorderRadius = 10;
            this.textSignUsername.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textSignUsername.DefaultText = "";
            this.textSignUsername.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textSignUsername.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textSignUsername.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textSignUsername.DisabledState.Parent = this.textSignUsername;
            this.textSignUsername.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textSignUsername.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textSignUsername.FocusedState.Parent = this.textSignUsername;
            this.textSignUsername.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSignUsername.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textSignUsername.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textSignUsername.HoverState.Parent = this.textSignUsername;
            this.textSignUsername.Location = new System.Drawing.Point(59, 390);
            this.textSignUsername.Margin = new System.Windows.Forms.Padding(4);
            this.textSignUsername.Name = "textSignUsername";
            this.textSignUsername.PasswordChar = '\0';
            this.textSignUsername.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textSignUsername.PlaceholderText = "Username*";
            this.textSignUsername.SelectedText = "";
            this.textSignUsername.ShadowDecoration.Parent = this.textSignUsername;
            this.textSignUsername.Size = new System.Drawing.Size(330, 37);
            this.textSignUsername.TabIndex = 34;
            // 
            // FormCreateAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Transport_beta.Properties.Resources.MicrosoftTeams_image__6_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.panelSignupBg);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "FormCreateAccount";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CreateAccount";
            this.Load += new System.EventHandler(this.FormCreateAccount_Load);
            this.panelSignupBg.ResumeLayout(false);
            this.panelSignup.ResumeLayout(false);
            this.panelSignup.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSignupBg;
        private System.Windows.Forms.Panel panelSignup;
        private System.Windows.Forms.Label labelFillall;
        private Guna.UI2.WinForms.Guna2DateTimePicker DBirth;
        private Guna.UI2.WinForms.Guna2CircleButton cbtnConfirmPass;
        private Guna.UI2.WinForms.Guna2TextBox textConfirmpass;
        private System.Windows.Forms.Label labelDob;
        private System.Windows.Forms.RadioButton rbtnOther;
        private System.Windows.Forms.RadioButton rbtnFemale;
        private System.Windows.Forms.Label labelGender;
        private System.Windows.Forms.RadioButton rbtnMale;
        private Guna.UI2.WinForms.Guna2TextBox textNID;
        private Guna.UI2.WinForms.Guna2TextBox textAddress;
        private Guna.UI2.WinForms.Guna2TextBox textPhone;
        private Guna.UI2.WinForms.Guna2TextBox textEmail;
        private Guna.UI2.WinForms.Guna2TextBox textLastName;
        private Guna.UI2.WinForms.Guna2TextBox textFirstName;
        private Guna.UI2.WinForms.Guna2CircleButton cbtnSignShowPass;
        private Guna.UI2.WinForms.Guna2Button btnSignup;
        private System.Windows.Forms.Label labelConfirmPass;
        private Guna.UI2.WinForms.Guna2TextBox textSignPassword;
        private System.Windows.Forms.Label labelSignUp;
        private Guna.UI2.WinForms.Guna2TextBox textSignUsername;
        private System.Windows.Forms.Label labelNotregistered;
        private System.Windows.Forms.LinkLabel linkLabelLogin;
        private System.Windows.Forms.Button btnMinimise;
        private System.Windows.Forms.Button btnAppClose;
    }
}