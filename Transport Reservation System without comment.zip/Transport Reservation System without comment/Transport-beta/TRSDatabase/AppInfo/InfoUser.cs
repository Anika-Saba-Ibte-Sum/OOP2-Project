﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRSDatabase.AppInfo
{
    public class InfoUser
    {
        //Using properties 
        public string Fname { set; get; }
        public string Lname { set; get; }
        public string NidNo { set; get; }
        public string Email { set; get; }
        public string PhoneNo { set; get; }
        public string Address { set; get; }
        public string Gender { set; get; }
        public DateTime Dob { set; get; }
        public string Username { set; get; }
        public string Password { set; get; }
        public string Role { set; get; }
    }
}
