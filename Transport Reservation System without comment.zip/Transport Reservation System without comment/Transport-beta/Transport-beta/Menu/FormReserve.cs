﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TRSDatabase.AppInfo;
using TRSDatabase.AppOperation;

namespace Transport_beta.Menu
{
    public partial class FormReserve : Form
    {
        private double Fare;
        OReserve Or = new OReserve();
   

        public FormReserve()
        {
            InitializeComponent();
        }

        private void cbType_SelectedIndexChanged(object sender, EventArgs e)//Transport type 
        {
           
            cboxBrand.Items.Clear(); cboxModel.Items.Clear();
            cboxBrand.Enabled = true;
            if (cboxBrand.Text != "") { cboxModel.Enabled = true; }
            else { cboxModel.Enabled = false; }

          
            try
            {
                List<string> Brands = Or.TransportColumn(cboxType.Text);
                foreach(string i in Brands)
                   cboxBrand.Items.Add(i);
            }
            catch (Exception exc) { MessageBox.Show(exc.ToString()); }

            //Clear Duration and Cost
            cboxDay.SelectedIndex = cboxDay.Items.IndexOf("0");
            cboxHour.SelectedIndex = cboxHour.Items.IndexOf("0");
            cboxMin.SelectedIndex = cboxMin.Items.IndexOf("00");
            lblCost.Text = "0";
        }

        private void cboxBrand_SelectedIndexChanged(object sender, EventArgs e)//Transport brand
        {
            

            //Clear permission of comboBox
            cboxModel.Items.Clear();
            if (cboxBrand.Text != "") { cboxModel.Enabled = true; }
            else { cboxModel.Enabled = false; }

            //OReserve Or = new OReserve();
            try
            {
                List<string> Models = Or.TransportColumn(cboxType.Text, cboxBrand.Text);
                foreach (string i in Models)
                    cboxModel.Items.Add(i);
            }
            catch (Exception exc) { MessageBox.Show(exc.ToString()); }

            //Clear Duration and Cost
            cboxDay.SelectedIndex = cboxDay.Items.IndexOf("0");
            cboxHour.SelectedIndex = cboxHour.Items.IndexOf("0");
            cboxMin.SelectedIndex = cboxMin.Items.IndexOf("00");
            lblCost.Text = "0";
        }

        private void cboxModel_SelectedIndexChanged(object sender, EventArgs e)//Transport model
        {
            
            //Clear Duration and Cost
            cboxDay.SelectedIndex = cboxDay.Items.IndexOf("0");
            cboxHour.SelectedIndex = cboxHour.Items.IndexOf("0");
            cboxMin.SelectedIndex = cboxMin.Items.IndexOf("00");
            lblCost.Text = "0";
        }

        private void FormReserve_Load(object sender, EventArgs e)
        {
            lblUser.Text = FormLogin.Username;
            Fare = 0;
            ReserveDate.Value = DateTime.Today;
            

            //Load Type ComboBox
          
            try
            {
                List<string> Types = Or.TransportColumn();
                foreach (string i in Types)
                    cboxType.Items.Add(i);
            }
            catch (Exception exc) { MessageBox.Show(exc.ToString()); }

            cboxDay.SelectedIndex = cboxDay.Items.IndexOf("0");
            cboxHour.SelectedIndex = cboxHour.Items.IndexOf("0");
            cboxMin.SelectedIndex = cboxMin.Items.IndexOf("00");
        }

        

        private void cboxDay_SelectedValueChanged(object sender, EventArgs e)
        {
            
            if(!FormLogin.check(cboxType.Text, cboxBrand.Text, cboxModel.Text) && cboxHour.Text=="0" && cboxMin.Text == "00")
            {
                try
                {
                    Fare = Or.GetFare(cboxType.Text, cboxBrand.Text, cboxModel.Text);
                }
                catch (Exception exc) { MessageBox.Show(exc.ToString());/*lblCost.Text = "0";*/ }
                
               
            }

            if (!FormLogin.check(cboxType.Text, cboxBrand.Text, cboxModel.Text, cboxHour.Text, cboxMin.Text))
            {
                lblCost.Text = (Math.Ceiling((Fare / 60) *
                (Double.Parse(cboxDay.Text) * 24 * 60 + Double.Parse(cboxHour.Text) * 60 + Double.Parse(cboxMin.Text)))).ToString("0");
            }
           
        }

        private void cboxHour_SelectedValueChanged(object sender, EventArgs e)
        {
            

            if (!FormLogin.check(cboxType.Text, cboxBrand.Text, cboxModel.Text) && cboxDay.Text == "0" && cboxMin.Text == "00")
            {
                try
                {
                    Fare = Or.GetFare(cboxType.Text, cboxBrand.Text, cboxModel.Text);
                }
                catch (Exception exc) { MessageBox.Show(exc.ToString());/*lblCost.Text = "0";*/ }
            }

            if (!FormLogin.check(cboxType.Text, cboxBrand.Text, cboxModel.Text, cboxDay.Text, cboxMin.Text))
            {
                lblCost.Text = (Math.Ceiling((Fare / 60) *
                (Double.Parse(cboxDay.Text) * 24 * 60 + Double.Parse(cboxHour.Text) * 60 + Double.Parse(cboxMin.Text)))).ToString("0");
            }
            
        }

        private void cboxMin_SelectedValueChanged(object sender, EventArgs e)
        {
           

            if (!FormLogin.check(cboxType.Text, cboxBrand.Text, cboxModel.Text) && cboxHour.Text == "0" && cboxDay.Text == "0")
            {
                try
                {
                    Fare = Or.GetFare(cboxType.Text, cboxBrand.Text, cboxModel.Text);
                }
                catch (Exception exc) { MessageBox.Show(exc.ToString());/*lblCost.Text = "0";*/ }

            }

            if (!FormLogin.check(cboxType.Text, cboxBrand.Text, cboxModel.Text, cboxDay.Text, cboxHour.Text))
            {
                lblCost.Text = (Math.Ceiling((Fare / 60) *
                (Double.Parse(cboxDay.Text) * 24 * 60 + Double.Parse(cboxHour.Text) * 60 + Double.Parse(cboxMin.Text)))).ToString("0");
            }
           
        }

        private void btnReserve_Click(object sender, EventArgs e)
        {
            InfoReserve Ir = new InfoReserve();
            
            Ir.Username = FormLogin.Username;
            Ir.Type = cboxType.Text;
            Ir.Brand = cboxBrand.Text;
            Ir.Model = cboxModel.Text;
            Ir.Date = ReserveDate.Value;
            Ir.From = textFrom.Text;
            Ir.To = textTo.Text;
            string day = cboxDay.Text; string hour = cboxHour.Text; string minute = cboxMin.Text;

            if (FormLogin.check(Ir.Type, Ir.Brand, Ir.Model, Ir.From, Ir.To) || (day=="0" && hour=="0" && minute=="00"))
            {
                labelFillall.Visible = true;
                return;
            }

            string Duration = "";
            if (Int32.Parse(cboxDay.Text) > 1) Duration += cboxDay.Text + " Days ";
            else if (Int32.Parse(cboxDay.Text) == 1) Duration += cboxDay.Text + " Day ";
            if (Int32.Parse(cboxHour.Text) > 1) Duration += cboxHour.Text + " Hours ";
            else if (Int32.Parse(cboxHour.Text) == 1) Duration += cboxHour.Text + " Hour ";
            if (Int32.Parse(cboxMin.Text) > 1) Duration += cboxMin.Text + " Minutes";
            else if (Int32.Parse(cboxMin.Text) == 1) Duration += cboxMin.Text + " Minute";
            Ir.Duration = Duration;

            Ir.TotalCost = (Math.Ceiling((Fare / 60) *
                    (Double.Parse(cboxDay.Text) * 24 * 60 + Double.Parse(cboxHour.Text) * 60 + Double.Parse(cboxMin.Text)))).ToString("0");
            lblCost.Text = Ir.TotalCost;

            if (labelFillall.Visible) labelFillall.Visible = false;

            try
            {
                int flag = Or.Reserve(Ir);
                if (flag > 0)
                    MessageBox.Show(Ir.Type + " has been reserved!");
                else MessageBox.Show("Error in reserving transport!");
            }
            catch (Exception exc) { MessageBox.Show(exc.ToString()); }
        }
    }
}
