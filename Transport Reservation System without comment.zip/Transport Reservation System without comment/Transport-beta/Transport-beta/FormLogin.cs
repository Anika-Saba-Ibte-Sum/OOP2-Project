﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using TRSDatabase.AppConnect;
using TRSDatabase.AppInfo;

namespace Transport_beta
{
    public partial class FormLogin : Form
    {
        public static string Username;
        public static string Fullname;
        public FormLogin()
        {
            InitializeComponent();
            panelLogin.BackColor = Color.FromArgb(100, Color.Black);
            panelLogin2.BackColor = Color.FromArgb(150, Color.AntiqueWhite);
         
        }

        //Check All Boxes If null or Empty
        public static bool check(params string[] s)
        {
            foreach (string i in s)
            {
                if (i == null || i == String.Empty)
                    return true;
            }
            return false;
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            InfoUserLogin Iuser = new InfoUserLogin();
            OUserLogin Ouser = new OUserLogin();

            Iuser.Username = textUsername.Text.ToLower();
            Iuser.Password = textPassword.Text.ToString();

            try
            {
                int flag = Ouser.SearchUser(Iuser);
                if (flag == 0)
                {
                    labelWrongUP.Visible = false;
                    Username = Iuser.Username;
                    Fullname = new OCAccount().Fullname(Username);
                    new Dashboard().Show();
                    this.Hide();
                }
                else if (flag == 1)
                {
                    labelWrongUP.Text = "*Wrong Password";
                    status2.Text = "*Wrong Password";
                    labelWrongUP.Visible = true;
                    textPassword.Clear();
                }
                else if (flag == 2 )
                {
                    labelWrongUP.Text = "*Wrong Username";
                    status2.Text = "*Wrong Username";
                    labelWrongUP.Visible = true;
                    textPassword.Clear();
                }
            } catch (Exception exc) { MessageBox.Show( exc.ToString( )); }
        }
        

        private void linkLabelSignUp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new FormCreateAccount().Show();
            this.Hide();
        }

        private void cbtnShowPass_MouseDown(object sender, MouseEventArgs e)
        {
            textPassword.PasswordChar = '\0';
            cbtnShowPass.Image = Properties.Resources.show;
        }

        private void cbtnShowPass_MouseUp(object sender, MouseEventArgs e)
        {
            textPassword.PasswordChar = '•';
            cbtnShowPass.Image = Properties.Resources.hide;
        }

        private void btnMinimise_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnAppClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textUsername_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
                textPassword.Focus();
        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        private void panelTitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }
    }
}