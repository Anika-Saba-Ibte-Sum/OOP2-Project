﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRSDatabase.AppOperation
{
    public class OHistory
    {
        SqlConnection DBconnect = new SqlConnection("Data Source=DESKTOP-H84DT5K;Initial Catalog=TRSalpha;Integrated Security=True");
        public SqlDataAdapter RHistory(string Username)
        {
            DBconnect.Open();
            SqlCommand cmd0 = new SqlCommand("Select * From UserInfo Where Role='Admin' AND Username ='" + Username + "'", DBconnect);
            SqlDataReader found = cmd0.ExecuteReader();
            if (!found.HasRows)
            {
                found.Close();
                SqlDataAdapter sqlDa = new SqlDataAdapter("Select Date, Duration, [Total Cost], [From], [To], Type, Brand, Model from Reservation where Username='" + Username +
                    "' Order By Date", DBconnect);
                DBconnect.Close();
                return sqlDa;
            }
            else
            {
                found.Close();
                SqlDataAdapter sqlDa = new SqlDataAdapter("Select * from Reservation Order By Date", DBconnect);
                DBconnect.Close();
                return sqlDa;
            }
        }
    }
}
