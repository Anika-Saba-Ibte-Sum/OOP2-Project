﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using TRSDatabase.AppInfo;
using TRSDatabase.AppOperation;

namespace Transport_beta.Menu
{
    public partial class FormTransport : Form
    {
        public FormTransport()
        {
            InitializeComponent();
        }

        private void RefDataGrid()
        {
            SqlDataAdapter sqlda = new OTransport().ShowTransport();
            DataTable dt = new DataTable();
            sqlda.Fill(dt);
            dataGridTransport.DataSource = dt;
        }
        private void FormTransport_Load(object sender, EventArgs e)
        {
            RefDataGrid();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            OTransport Ot = new OTransport();
            InfoTransport It = new InfoTransport();
            It.RegNo = textRegNo.Text;
            It.Type = cboxType.Text;
            It.Brand = textBrand.Text;
            It.Model = textModel.Text;
            It.Fare = textFare.Text;
            It.Available = cboxAvailable.Text;

            if (FormLogin.check(It.RegNo, It.Type, It.Brand, It.Model, It.Fare, It.Available))
            {
                lblFillall.Visible = true;
                return;
            }

            try
            {
                int flag = Ot.AddTransport(It);
                if (flag > 0)
                {
                    lblFillall.Visible = false;
                    RefDataGrid();
                    MessageBox.Show("Transport has been added!");
                }
                else MessageBox.Show("Registration id is already used!");
            }
            catch (Exception exc) { MessageBox.Show(exc.ToString()); }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            OTransport Ot = new OTransport();
            InfoTransport It = new InfoTransport();
            It.RegNo = textRegNo.Text;
            It.Type = cboxType.Text;
            It.Brand = textBrand.Text;
            It.Model = textModel.Text;
            It.Fare = textFare.Text;
            It.Available = cboxAvailable.Text;

            if (FormLogin.check(It.RegNo, It.Type, It.Brand, It.Model, It.Fare, It.Available))
            {
                lblFillall.Visible = true;
                return;
            }

            try
            {
                int flag = Ot.EditTransport(It);
                if (flag > 0)
                {
                    lblFillall.Visible = false;
                    RefDataGrid();
                    MessageBox.Show("Selected Transport has been updated!");
                }
                else MessageBox.Show("Registration id is not found!");
            }
            catch (Exception exc) { MessageBox.Show(exc.ToString()); }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            OTransport Ot = new OTransport();
            InfoTransport It = new InfoTransport();
            It.RegNo = textRegNo.Text;
            It.Type = cboxType.Text;
            It.Brand = textBrand.Text;
            It.Model = textModel.Text;
            It.Fare = textFare.Text;
            It.Available = cboxAvailable.Text;

            if (FormLogin.check(It.RegNo, It.Type, It.Brand, It.Model, It.Fare, It.Available))
            {
                lblFillall.Visible = true;
                return;
            }

            try
            {
                int flag = Ot.DeleteTransport(It);
                if (flag > 0)
                {
                    lblFillall.Visible = false;
                    RefDataGrid();
                    MessageBox.Show("Selected Transport has been deleted!");
                }
                else MessageBox.Show("Registration id is not found!");
            }
            catch (Exception exc) { MessageBox.Show(exc.ToString()); }
        }

        private void dataGridTransport_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textRegNo.Text = dataGridTransport.SelectedRows[0].Cells[0].Value.ToString();
            cboxType.Text = dataGridTransport.SelectedRows[0].Cells[1].Value.ToString(); ;
            textBrand.Text = dataGridTransport.SelectedRows[0].Cells[2].Value.ToString(); ;
            textModel.Text = dataGridTransport.SelectedRows[0].Cells[3].Value.ToString(); ;
            textFare.Text = dataGridTransport.SelectedRows[0].Cells[4].Value.ToString(); ;
            cboxAvailable.Text = dataGridTransport.SelectedRows[0].Cells[5].Value.ToString(); ;
        }
    }
}
