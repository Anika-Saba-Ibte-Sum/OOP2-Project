﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRSDatabase.AppInfo
{
    public class InfoUserLogin
    {
        //Using properties 
        public string Username { set; get; }
        public string Password { set; get; }
    }
}
