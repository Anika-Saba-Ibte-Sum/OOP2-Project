﻿
namespace Transport_beta.Menu
{
    partial class FormUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblUserList = new System.Windows.Forms.Label();
            this.dataGridUser = new Guna.UI2.WinForms.Guna2DataGridView();
            this.panelUser = new System.Windows.Forms.Panel();
            this.lblRole = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.cboxRole = new System.Windows.Forms.ComboBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblNidNo = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.labelFillall = new System.Windows.Forms.Label();
            this.DBirth = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.labelDob = new System.Windows.Forms.Label();
            this.btnUpdate = new Guna.UI2.WinForms.Guna2Button();
            this.btnAdd = new Guna.UI2.WinForms.Guna2Button();
            this.rbtnOther = new System.Windows.Forms.RadioButton();
            this.btnDelete = new Guna.UI2.WinForms.Guna2Button();
            this.rbtnFemale = new System.Windows.Forms.RadioButton();
            this.labelGender = new System.Windows.Forms.Label();
            this.rbtnMale = new System.Windows.Forms.RadioButton();
            this.textNID = new Guna.UI2.WinForms.Guna2TextBox();
            this.textAddress = new Guna.UI2.WinForms.Guna2TextBox();
            this.textPhone = new Guna.UI2.WinForms.Guna2TextBox();
            this.textEmail = new Guna.UI2.WinForms.Guna2TextBox();
            this.textLastName = new Guna.UI2.WinForms.Guna2TextBox();
            this.textFirstName = new Guna.UI2.WinForms.Guna2TextBox();
            this.cbtnShowPass = new Guna.UI2.WinForms.Guna2CircleButton();
            this.textPassword = new Guna.UI2.WinForms.Guna2TextBox();
            this.textUsername = new Guna.UI2.WinForms.Guna2TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridUser)).BeginInit();
            this.panelUser.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblUserList
            // 
            this.lblUserList.AutoSize = true;
            this.lblUserList.BackColor = System.Drawing.Color.Transparent;
            this.lblUserList.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserList.Location = new System.Drawing.Point(635, 26);
            this.lblUserList.Name = "lblUserList";
            this.lblUserList.Size = new System.Drawing.Size(92, 25);
            this.lblUserList.TabIndex = 6;
            this.lblUserList.Text = "User List";
            // 
            // dataGridUser
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dataGridUser.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridUser.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridUser.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridUser.BackgroundColor = System.Drawing.Color.White;
            this.dataGridUser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridUser.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridUser.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.IndianRed;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridUser.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridUser.ColumnHeadersHeight = 22;
            this.dataGridUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridUser.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridUser.EnableHeadersVisualStyles = false;
            this.dataGridUser.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataGridUser.Location = new System.Drawing.Point(413, 87);
            this.dataGridUser.Name = "dataGridUser";
            this.dataGridUser.ReadOnly = true;
            this.dataGridUser.RowHeadersVisible = false;
            this.dataGridUser.RowTemplate.Height = 26;
            this.dataGridUser.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridUser.Size = new System.Drawing.Size(588, 406);
            this.dataGridUser.TabIndex = 5;
            this.dataGridUser.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dataGridUser.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dataGridUser.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dataGridUser.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dataGridUser.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dataGridUser.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dataGridUser.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataGridUser.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Maroon;
            this.dataGridUser.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridUser.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridUser.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dataGridUser.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridUser.ThemeStyle.HeaderStyle.Height = 22;
            this.dataGridUser.ThemeStyle.ReadOnly = true;
            this.dataGridUser.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.Gray;
            this.dataGridUser.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridUser.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridUser.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dataGridUser.ThemeStyle.RowsStyle.Height = 26;
            this.dataGridUser.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataGridUser.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dataGridUser.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridUser_CellClick);
            // 
            // panelUser
            // 
            this.panelUser.Controls.Add(this.textUsername);
            this.panelUser.Controls.Add(this.lblRole);
            this.panelUser.Controls.Add(this.lblPassword);
            this.panelUser.Controls.Add(this.lblUser);
            this.panelUser.Controls.Add(this.cboxRole);
            this.panelUser.Controls.Add(this.lblAddress);
            this.panelUser.Controls.Add(this.lblPhone);
            this.panelUser.Controls.Add(this.lblEmail);
            this.panelUser.Controls.Add(this.lblNidNo);
            this.panelUser.Controls.Add(this.lblName);
            this.panelUser.Controls.Add(this.labelFillall);
            this.panelUser.Controls.Add(this.DBirth);
            this.panelUser.Controls.Add(this.labelDob);
            this.panelUser.Controls.Add(this.btnUpdate);
            this.panelUser.Controls.Add(this.btnAdd);
            this.panelUser.Controls.Add(this.rbtnOther);
            this.panelUser.Controls.Add(this.btnDelete);
            this.panelUser.Controls.Add(this.rbtnFemale);
            this.panelUser.Controls.Add(this.labelGender);
            this.panelUser.Controls.Add(this.rbtnMale);
            this.panelUser.Controls.Add(this.textNID);
            this.panelUser.Controls.Add(this.textAddress);
            this.panelUser.Controls.Add(this.textPhone);
            this.panelUser.Controls.Add(this.textEmail);
            this.panelUser.Controls.Add(this.textLastName);
            this.panelUser.Controls.Add(this.textFirstName);
            this.panelUser.Controls.Add(this.cbtnShowPass);
            this.panelUser.Controls.Add(this.textPassword);
            this.panelUser.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelUser.Location = new System.Drawing.Point(0, 0);
            this.panelUser.Name = "panelUser";
            this.panelUser.Size = new System.Drawing.Size(407, 552);
            this.panelUser.TabIndex = 4;
            // 
            // lblRole
            // 
            this.lblRole.AutoSize = true;
            this.lblRole.BackColor = System.Drawing.Color.Transparent;
            this.lblRole.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRole.Location = new System.Drawing.Point(33, 416);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(56, 20);
            this.lblRole.TabIndex = 83;
            this.lblRole.Text = "Role  :";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.BackColor = System.Drawing.Color.Transparent;
            this.lblPassword.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.Location = new System.Drawing.Point(33, 377);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(83, 20);
            this.lblPassword.TabIndex = 82;
            this.lblPassword.Text = "Password:";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.BackColor = System.Drawing.Color.Transparent;
            this.lblUser.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.Location = new System.Drawing.Point(33, 335);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(86, 20);
            this.lblUser.TabIndex = 80;
            this.lblUser.Text = "Username:";
            // 
            // cboxRole
            // 
            this.cboxRole.AllowDrop = true;
            this.cboxRole.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cboxRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxRole.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxRole.FormattingEnabled = true;
            this.cboxRole.Items.AddRange(new object[] {
            "Customer",
            "Admin"});
            this.cboxRole.Location = new System.Drawing.Point(130, 412);
            this.cboxRole.MaxDropDownItems = 7;
            this.cboxRole.Name = "cboxRole";
            this.cboxRole.Size = new System.Drawing.Size(248, 27);
            this.cboxRole.TabIndex = 79;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblAddress.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.Location = new System.Drawing.Point(33, 196);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(86, 20);
            this.lblAddress.TabIndex = 78;
            this.lblAddress.Text = "Address   :";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.BackColor = System.Drawing.Color.Transparent;
            this.lblPhone.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhone.Location = new System.Drawing.Point(33, 157);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(84, 20);
            this.lblPhone.TabIndex = 77;
            this.lblPhone.Text = "Phone     :";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblEmail.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(33, 120);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(85, 20);
            this.lblEmail.TabIndex = 76;
            this.lblEmail.Text = "E-mail     :";
            // 
            // lblNidNo
            // 
            this.lblNidNo.AutoSize = true;
            this.lblNidNo.BackColor = System.Drawing.Color.Transparent;
            this.lblNidNo.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNidNo.Location = new System.Drawing.Point(33, 82);
            this.lblNidNo.Name = "lblNidNo";
            this.lblNidNo.Size = new System.Drawing.Size(87, 20);
            this.lblNidNo.TabIndex = 75;
            this.lblNidNo.Text = "NID No.  :";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.Color.Transparent;
            this.lblName.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(33, 46);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(86, 20);
            this.lblName.TabIndex = 74;
            this.lblName.Text = "Name      :";
            // 
            // labelFillall
            // 
            this.labelFillall.AutoSize = true;
            this.labelFillall.BackColor = System.Drawing.Color.Transparent;
            this.labelFillall.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFillall.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelFillall.Location = new System.Drawing.Point(82, 450);
            this.labelFillall.Name = "labelFillall";
            this.labelFillall.Size = new System.Drawing.Size(130, 20);
            this.labelFillall.TabIndex = 73;
            this.labelFillall.Text = "*Fill all the details";
            this.labelFillall.Visible = false;
            // 
            // DBirth
            // 
            this.DBirth.BackColor = System.Drawing.Color.Transparent;
            this.DBirth.BorderRadius = 5;
            this.DBirth.CheckedState.Parent = this.DBirth;
            this.DBirth.FillColor = System.Drawing.Color.White;
            this.DBirth.Font = new System.Drawing.Font("Bahnschrift Condensed", 13F);
            this.DBirth.ForeColor = System.Drawing.Color.Black;
            this.DBirth.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.DBirth.HoverState.Parent = this.DBirth;
            this.DBirth.Location = new System.Drawing.Point(152, 288);
            this.DBirth.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.DBirth.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.DBirth.Name = "DBirth";
            this.DBirth.ShadowDecoration.Parent = this.DBirth;
            this.DBirth.Size = new System.Drawing.Size(226, 34);
            this.DBirth.TabIndex = 56;
            this.DBirth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.DBirth.Value = new System.DateTime(2021, 7, 24, 13, 14, 7, 837);
            // 
            // labelDob
            // 
            this.labelDob.AutoSize = true;
            this.labelDob.BackColor = System.Drawing.Color.Transparent;
            this.labelDob.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDob.Location = new System.Drawing.Point(33, 295);
            this.labelDob.Name = "labelDob";
            this.labelDob.Size = new System.Drawing.Size(108, 20);
            this.labelDob.TabIndex = 70;
            this.labelDob.Text = "Date of Birth:";
            // 
            // btnUpdate
            // 
            this.btnUpdate.BorderRadius = 20;
            this.btnUpdate.CheckedState.Parent = this.btnUpdate;
            this.btnUpdate.CustomImages.Parent = this.btnUpdate;
            this.btnUpdate.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnUpdate.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnUpdate.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnUpdate.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnUpdate.DisabledState.Parent = this.btnUpdate;
            this.btnUpdate.FillColor = System.Drawing.Color.IndianRed;
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.HoverState.Parent = this.btnUpdate;
            this.btnUpdate.Location = new System.Drawing.Point(178, 483);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.ShadowDecoration.Parent = this.btnUpdate;
            this.btnUpdate.Size = new System.Drawing.Size(81, 45);
            this.btnUpdate.TabIndex = 7;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BorderRadius = 20;
            this.btnAdd.CheckedState.Parent = this.btnAdd;
            this.btnAdd.CustomImages.Parent = this.btnAdd;
            this.btnAdd.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnAdd.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnAdd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnAdd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnAdd.DisabledState.Parent = this.btnAdd;
            this.btnAdd.FillColor = System.Drawing.Color.IndianRed;
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.HoverState.Parent = this.btnAdd;
            this.btnAdd.Location = new System.Drawing.Point(68, 483);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.ShadowDecoration.Parent = this.btnAdd;
            this.btnAdd.Size = new System.Drawing.Size(81, 45);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // rbtnOther
            // 
            this.rbtnOther.AutoSize = true;
            this.rbtnOther.BackColor = System.Drawing.Color.Transparent;
            this.rbtnOther.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnOther.Location = new System.Drawing.Point(284, 254);
            this.rbtnOther.Name = "rbtnOther";
            this.rbtnOther.Size = new System.Drawing.Size(68, 24);
            this.rbtnOther.TabIndex = 69;
            this.rbtnOther.TabStop = true;
            this.rbtnOther.Text = "Other";
            this.rbtnOther.UseVisualStyleBackColor = false;
            // 
            // btnDelete
            // 
            this.btnDelete.BorderRadius = 20;
            this.btnDelete.CheckedState.Parent = this.btnDelete;
            this.btnDelete.CustomImages.Parent = this.btnDelete;
            this.btnDelete.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDelete.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnDelete.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnDelete.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnDelete.DisabledState.Parent = this.btnDelete;
            this.btnDelete.FillColor = System.Drawing.Color.IndianRed;
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.HoverState.Parent = this.btnDelete;
            this.btnDelete.Location = new System.Drawing.Point(285, 483);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.ShadowDecoration.Parent = this.btnDelete;
            this.btnDelete.Size = new System.Drawing.Size(81, 45);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.Text = "Delete";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // rbtnFemale
            // 
            this.rbtnFemale.AutoSize = true;
            this.rbtnFemale.BackColor = System.Drawing.Color.Transparent;
            this.rbtnFemale.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnFemale.Location = new System.Drawing.Point(204, 254);
            this.rbtnFemale.Name = "rbtnFemale";
            this.rbtnFemale.Size = new System.Drawing.Size(79, 24);
            this.rbtnFemale.TabIndex = 68;
            this.rbtnFemale.TabStop = true;
            this.rbtnFemale.Text = "Female";
            this.rbtnFemale.UseVisualStyleBackColor = false;
            // 
            // labelGender
            // 
            this.labelGender.AutoSize = true;
            this.labelGender.BackColor = System.Drawing.Color.Transparent;
            this.labelGender.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGender.Location = new System.Drawing.Point(33, 255);
            this.labelGender.Name = "labelGender";
            this.labelGender.Size = new System.Drawing.Size(85, 20);
            this.labelGender.TabIndex = 67;
            this.labelGender.Text = "Gender*  :";
            // 
            // rbtnMale
            // 
            this.rbtnMale.AutoSize = true;
            this.rbtnMale.BackColor = System.Drawing.Color.Transparent;
            this.rbtnMale.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnMale.Location = new System.Drawing.Point(135, 254);
            this.rbtnMale.Name = "rbtnMale";
            this.rbtnMale.Size = new System.Drawing.Size(63, 24);
            this.rbtnMale.TabIndex = 66;
            this.rbtnMale.TabStop = true;
            this.rbtnMale.Text = "Male";
            this.rbtnMale.UseVisualStyleBackColor = false;
            // 
            // textNID
            // 
            this.textNID.AcceptsReturn = true;
            this.textNID.BackColor = System.Drawing.Color.Transparent;
            this.textNID.BorderRadius = 10;
            this.textNID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textNID.DefaultText = "";
            this.textNID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textNID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textNID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textNID.DisabledState.Parent = this.textNID;
            this.textNID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textNID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textNID.FocusedState.Parent = this.textNID;
            this.textNID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textNID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textNID.HoverState.Parent = this.textNID;
            this.textNID.Location = new System.Drawing.Point(130, 77);
            this.textNID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textNID.Name = "textNID";
            this.textNID.PasswordChar = '\0';
            this.textNID.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textNID.PlaceholderText = "";
            this.textNID.SelectedText = "";
            this.textNID.ShadowDecoration.Parent = this.textNID;
            this.textNID.Size = new System.Drawing.Size(248, 31);
            this.textNID.TabIndex = 65;
            // 
            // textAddress
            // 
            this.textAddress.AcceptsReturn = true;
            this.textAddress.BackColor = System.Drawing.Color.Transparent;
            this.textAddress.BorderRadius = 10;
            this.textAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textAddress.DefaultText = "";
            this.textAddress.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textAddress.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textAddress.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textAddress.DisabledState.Parent = this.textAddress;
            this.textAddress.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textAddress.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textAddress.FocusedState.Parent = this.textAddress;
            this.textAddress.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.textAddress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textAddress.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textAddress.HoverState.Parent = this.textAddress;
            this.textAddress.Location = new System.Drawing.Point(130, 188);
            this.textAddress.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textAddress.Multiline = true;
            this.textAddress.Name = "textAddress";
            this.textAddress.PasswordChar = '\0';
            this.textAddress.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textAddress.PlaceholderText = "";
            this.textAddress.SelectedText = "";
            this.textAddress.ShadowDecoration.Parent = this.textAddress;
            this.textAddress.Size = new System.Drawing.Size(248, 53);
            this.textAddress.TabIndex = 64;
            // 
            // textPhone
            // 
            this.textPhone.AcceptsReturn = true;
            this.textPhone.BackColor = System.Drawing.Color.Transparent;
            this.textPhone.BorderRadius = 10;
            this.textPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textPhone.DefaultText = "";
            this.textPhone.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textPhone.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textPhone.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textPhone.DisabledState.Parent = this.textPhone;
            this.textPhone.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textPhone.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textPhone.FocusedState.Parent = this.textPhone;
            this.textPhone.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.textPhone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textPhone.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textPhone.HoverState.Parent = this.textPhone;
            this.textPhone.Location = new System.Drawing.Point(130, 151);
            this.textPhone.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textPhone.Name = "textPhone";
            this.textPhone.PasswordChar = '\0';
            this.textPhone.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textPhone.PlaceholderText = "";
            this.textPhone.SelectedText = "";
            this.textPhone.ShadowDecoration.Parent = this.textPhone;
            this.textPhone.Size = new System.Drawing.Size(248, 31);
            this.textPhone.TabIndex = 63;
            // 
            // textEmail
            // 
            this.textEmail.AcceptsReturn = true;
            this.textEmail.BackColor = System.Drawing.Color.Transparent;
            this.textEmail.BorderRadius = 10;
            this.textEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textEmail.DefaultText = "";
            this.textEmail.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textEmail.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textEmail.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textEmail.DisabledState.Parent = this.textEmail;
            this.textEmail.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textEmail.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textEmail.FocusedState.Parent = this.textEmail;
            this.textEmail.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.textEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textEmail.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textEmail.HoverState.Parent = this.textEmail;
            this.textEmail.Location = new System.Drawing.Point(130, 114);
            this.textEmail.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textEmail.Name = "textEmail";
            this.textEmail.PasswordChar = '\0';
            this.textEmail.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textEmail.PlaceholderText = "";
            this.textEmail.SelectedText = "";
            this.textEmail.ShadowDecoration.Parent = this.textEmail;
            this.textEmail.Size = new System.Drawing.Size(248, 31);
            this.textEmail.TabIndex = 62;
            // 
            // textLastName
            // 
            this.textLastName.AcceptsReturn = true;
            this.textLastName.BackColor = System.Drawing.Color.Transparent;
            this.textLastName.BorderRadius = 10;
            this.textLastName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textLastName.DefaultText = "";
            this.textLastName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textLastName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textLastName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textLastName.DisabledState.Parent = this.textLastName;
            this.textLastName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textLastName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textLastName.FocusedState.Parent = this.textLastName;
            this.textLastName.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.textLastName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textLastName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textLastName.HoverState.Parent = this.textLastName;
            this.textLastName.Location = new System.Drawing.Point(252, 40);
            this.textLastName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textLastName.Name = "textLastName";
            this.textLastName.PasswordChar = '\0';
            this.textLastName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textLastName.PlaceholderText = "Last Name";
            this.textLastName.SelectedText = "";
            this.textLastName.ShadowDecoration.Parent = this.textLastName;
            this.textLastName.Size = new System.Drawing.Size(121, 31);
            this.textLastName.TabIndex = 61;
            // 
            // textFirstName
            // 
            this.textFirstName.AcceptsReturn = true;
            this.textFirstName.BackColor = System.Drawing.Color.Transparent;
            this.textFirstName.BorderRadius = 10;
            this.textFirstName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textFirstName.DefaultText = "";
            this.textFirstName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textFirstName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textFirstName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textFirstName.DisabledState.Parent = this.textFirstName;
            this.textFirstName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textFirstName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textFirstName.FocusedState.Parent = this.textFirstName;
            this.textFirstName.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.textFirstName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textFirstName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textFirstName.HoverState.Parent = this.textFirstName;
            this.textFirstName.Location = new System.Drawing.Point(130, 40);
            this.textFirstName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textFirstName.Name = "textFirstName";
            this.textFirstName.PasswordChar = '\0';
            this.textFirstName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textFirstName.PlaceholderText = "First Name";
            this.textFirstName.SelectedText = "";
            this.textFirstName.ShadowDecoration.Parent = this.textFirstName;
            this.textFirstName.Size = new System.Drawing.Size(121, 31);
            this.textFirstName.TabIndex = 60;
            // 
            // cbtnShowPass
            // 
            this.cbtnShowPass.BackColor = System.Drawing.Color.White;
            this.cbtnShowPass.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cbtnShowPass.BorderColor = System.Drawing.Color.White;
            this.cbtnShowPass.CheckedState.Parent = this.cbtnShowPass;
            this.cbtnShowPass.CustomImages.Parent = this.cbtnShowPass;
            this.cbtnShowPass.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.cbtnShowPass.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.cbtnShowPass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.cbtnShowPass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.cbtnShowPass.DisabledState.Parent = this.cbtnShowPass;
            this.cbtnShowPass.FillColor = System.Drawing.Color.White;
            this.cbtnShowPass.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cbtnShowPass.ForeColor = System.Drawing.Color.White;
            this.cbtnShowPass.HoverState.Parent = this.cbtnShowPass;
            this.cbtnShowPass.Image = global::Transport_beta.Properties.Resources.hide;
            this.cbtnShowPass.ImageSize = new System.Drawing.Size(18, 18);
            this.cbtnShowPass.Location = new System.Drawing.Point(339, 372);
            this.cbtnShowPass.Name = "cbtnShowPass";
            this.cbtnShowPass.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.cbtnShowPass.ShadowDecoration.Parent = this.cbtnShowPass;
            this.cbtnShowPass.Size = new System.Drawing.Size(26, 25);
            this.cbtnShowPass.TabIndex = 59;
            this.cbtnShowPass.Visible = false;
            this.cbtnShowPass.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cbtnShowPass_MouseDown);
            this.cbtnShowPass.MouseUp += new System.Windows.Forms.MouseEventHandler(this.cbtnShowPass_MouseUp);
            // 
            // textPassword
            // 
            this.textPassword.BackColor = System.Drawing.Color.Transparent;
            this.textPassword.BorderRadius = 10;
            this.textPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textPassword.DefaultText = "";
            this.textPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textPassword.DisabledState.Parent = this.textPassword;
            this.textPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textPassword.FocusedState.Parent = this.textPassword;
            this.textPassword.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.textPassword.ForeColor = System.Drawing.Color.Black;
            this.textPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textPassword.HoverState.Parent = this.textPassword;
            this.textPassword.Location = new System.Drawing.Point(130, 368);
            this.textPassword.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textPassword.Name = "textPassword";
            this.textPassword.PasswordChar = '•';
            this.textPassword.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textPassword.PlaceholderText = "";
            this.textPassword.SelectedText = "";
            this.textPassword.ShadowDecoration.Parent = this.textPassword;
            this.textPassword.Size = new System.Drawing.Size(248, 31);
            this.textPassword.TabIndex = 57;
            this.textPassword.Click += new System.EventHandler(this.textPassword_Click);
            // 
            // textUsername
            // 
            this.textUsername.AcceptsReturn = true;
            this.textUsername.BackColor = System.Drawing.Color.Transparent;
            this.textUsername.BorderRadius = 10;
            this.textUsername.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textUsername.DefaultText = "";
            this.textUsername.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textUsername.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textUsername.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textUsername.DisabledState.Parent = this.textUsername;
            this.textUsername.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textUsername.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textUsername.FocusedState.Parent = this.textUsername;
            this.textUsername.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.textUsername.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textUsername.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textUsername.HoverState.Parent = this.textUsername;
            this.textUsername.Location = new System.Drawing.Point(130, 329);
            this.textUsername.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textUsername.Name = "textUsername";
            this.textUsername.PasswordChar = '\0';
            this.textUsername.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textUsername.PlaceholderText = "";
            this.textUsername.SelectedText = "";
            this.textUsername.ShadowDecoration.Parent = this.textUsername;
            this.textUsername.Size = new System.Drawing.Size(248, 31);
            this.textUsername.TabIndex = 84;
            // 
            // FormUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1013, 552);
            this.Controls.Add(this.lblUserList);
            this.Controls.Add(this.dataGridUser);
            this.Controls.Add(this.panelUser);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormUser";
            this.Text = "Users";
            this.Load += new System.EventHandler(this.FormUser_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridUser)).EndInit();
            this.panelUser.ResumeLayout(false);
            this.panelUser.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblUserList;
        private Guna.UI2.WinForms.Guna2DataGridView dataGridUser;
        private System.Windows.Forms.Panel panelUser;
        private Guna.UI2.WinForms.Guna2Button btnDelete;
        private Guna.UI2.WinForms.Guna2Button btnUpdate;
        private Guna.UI2.WinForms.Guna2Button btnAdd;
        private System.Windows.Forms.Label labelFillall;
        private Guna.UI2.WinForms.Guna2DateTimePicker DBirth;
        private System.Windows.Forms.Label labelDob;
        private System.Windows.Forms.RadioButton rbtnOther;
        private System.Windows.Forms.RadioButton rbtnFemale;
        private System.Windows.Forms.Label labelGender;
        private System.Windows.Forms.RadioButton rbtnMale;
        private Guna.UI2.WinForms.Guna2TextBox textNID;
        private Guna.UI2.WinForms.Guna2TextBox textAddress;
        private Guna.UI2.WinForms.Guna2TextBox textPhone;
        private Guna.UI2.WinForms.Guna2TextBox textEmail;
        private Guna.UI2.WinForms.Guna2TextBox textLastName;
        private Guna.UI2.WinForms.Guna2TextBox textFirstName;
        private Guna.UI2.WinForms.Guna2CircleButton cbtnShowPass;
        private Guna.UI2.WinForms.Guna2TextBox textPassword;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblNidNo;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.ComboBox cboxRole;
        private Guna.UI2.WinForms.Guna2TextBox textUsername;
    }
}