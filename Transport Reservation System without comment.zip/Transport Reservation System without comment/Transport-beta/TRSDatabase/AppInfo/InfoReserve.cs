﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRSDatabase.AppInfo
{
    public class InfoReserve
    {
        //Using properties 
        public string Username { set; get; }
        public string Type { set; get; }
        public string Brand { set; get; }
        public string Model { set; get; }
        public DateTime Date { set; get; }
        public string From { set; get; }
        public string To { set; get; }
        public string Duration { set; get; }
        public string TotalCost { set; get; }
    }
}