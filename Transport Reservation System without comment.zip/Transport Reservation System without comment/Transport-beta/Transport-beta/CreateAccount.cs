﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using TRSDatabase.AppConnect;
using TRSDatabase.AppInfo;

namespace Transport_beta
{
    public partial class FormCreateAccount : Form
    {
        public FormCreateAccount()
        {
            InitializeComponent();
            panelSignupBg.BackColor = Color.FromArgb(100, Color.Black);
            panelSignup.BackColor = Color.FromArgb(150, Color.AntiqueWhite);
        }
       
        private void btnSignup_Click(object sender, EventArgs e)
        {
            var FName = textFirstName.Text;
            var LName = textLastName.Text;
            var NID = textNID.Text;
            var Email = textEmail.Text;
            var PhoneNo = textPhone.Text;
            var Address = textAddress.Text;
            var UserName = textSignUsername.Text.ToLower();
            var Password = textSignPassword.Text;
            var Cpass = textConfirmpass.Text;
            
            if (FormLogin.check(FName, LName, Email, PhoneNo, Address, UserName, Password, Cpass) 
                    || (!rbtnMale.Checked && !rbtnFemale.Checked && !rbtnOther.Checked))
            {
                labelFillall.Visible = true;
                return;
            }

            //Gender Button
            RadioButton rb = panelSignup.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Checked);
            string Gender = rb.Text;

            //Date of Birth 
            DateTime BirthDate = DBirth.Value;
            TimeSpan timeSpan = DateTime.Now - BirthDate;
            int Age = (int)(timeSpan.TotalDays / 365); //.ToString("0");
            if(Age < 10)
            {
                MessageBox.Show("User must be minimum 10 years old");
                labelFillall.Visible = true;
                return;
            }

            InfoUser Iuser = new InfoUser();
            OCAccount OCuser = new OCAccount();
            Iuser.Fname = FName;
            Iuser.Lname = LName;
            Iuser.NidNo = NID;
            Iuser.Email = Email;
            Iuser.PhoneNo = PhoneNo;
            Iuser.Address = Address;
            Iuser.Gender = Gender;
            Iuser.Dob = BirthDate;
            Iuser.Username = UserName;
            Iuser.Password = Password;
            Iuser.Role = "Customer";

            try
            {
                int flag = OCuser.Add(Iuser);
                if(flag > 0)
                {
                    labelFillall.Visible = false;
                    new FormLogin().Show();
                    this.Close();
                    MessageBox.Show("Account has been created!");
                }
                else if (flag == 2)
                {
                    MessageBox.Show("Username already exists!"); ;
                }
                else MessageBox.Show("Account not found!");
            }
            catch(Exception exc) { MessageBox.Show(exc.ToString()); }
        }

        private void linkLabelLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new FormLogin().Show();
            this.Close();
        }

        private void cbtnSignShowPass_MouseDown(object sender, MouseEventArgs e)
        {
            textSignPassword.PasswordChar = '\0';
            cbtnSignShowPass.Image = Properties.Resources.show;
        }

        private void cbtnSignShowPass_MouseUp(object sender, MouseEventArgs e)
        {
            textSignPassword.PasswordChar = '•';
            cbtnSignShowPass.Image = Properties.Resources.hide;
        }

        private void cbtnConfirmPass_MouseDown(object sender, MouseEventArgs e)
        {
            textConfirmpass.PasswordChar = '\0';
            cbtnConfirmPass.Image = Properties.Resources.show;
        }

        private void cbtnConfirmPass_MouseUp(object sender, MouseEventArgs e)
        {
            textConfirmpass.PasswordChar = '•';
            cbtnConfirmPass.Image = Properties.Resources.hide;
        }

        private void textSignPassword_MouseClick(object sender, MouseEventArgs e)
        {
            cbtnSignShowPass.Visible = true;
        }

        private void textConfirmpass_MouseClick(object sender, MouseEventArgs e)
        {
            cbtnConfirmPass.Visible = true;
        }

        private void textConfirmpass_MouseLeave(object sender, EventArgs e)
        {
            if (textSignPassword.Text != textConfirmpass.Text)
               labelConfirmPass.Visible = true;
            else labelConfirmPass.Visible = false;
        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);
        private void panelTitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void btnMinimise_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnAppClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FormCreateAccount_Load(object sender, EventArgs e)
        {
            DBirth.Value = DateTime.Today;
        }
    }
}