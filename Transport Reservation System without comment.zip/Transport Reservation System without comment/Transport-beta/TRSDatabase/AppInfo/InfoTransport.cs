﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRSDatabase.AppInfo
{
    public class InfoTransport
    {
        //Using properties 
        public string RegNo { set; get; }
        public string Type { set; get; }
        public string Brand { set; get; }
        public string Model { set; get; }
        public string Fare { set; get; }
        public string Available { set; get; }
    }
}
