﻿
namespace Transport_beta.Menu
{
    partial class FormTransport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelTransport = new System.Windows.Forms.Panel();
            this.lblFillall = new System.Windows.Forms.Label();
            this.cboxAvailable = new System.Windows.Forms.ComboBox();
            this.lblAvailable = new System.Windows.Forms.Label();
            this.textModel = new Guna.UI2.WinForms.Guna2TextBox();
            this.textBrand = new Guna.UI2.WinForms.Guna2TextBox();
            this.textRegNo = new Guna.UI2.WinForms.Guna2TextBox();
            this.textFare = new Guna.UI2.WinForms.Guna2TextBox();
            this.lblFare = new System.Windows.Forms.Label();
            this.lebelRegNo = new System.Windows.Forms.Label();
            this.btnDelete = new Guna.UI2.WinForms.Guna2Button();
            this.btnUpdate = new Guna.UI2.WinForms.Guna2Button();
            this.labelModel = new System.Windows.Forms.Label();
            this.btnAdd = new Guna.UI2.WinForms.Guna2Button();
            this.labelBrand = new System.Windows.Forms.Label();
            this.labelType = new System.Windows.Forms.Label();
            this.cboxType = new System.Windows.Forms.ComboBox();
            this.lblTransportList = new System.Windows.Forms.Label();
            this.dataGridTransport = new Guna.UI2.WinForms.Guna2DataGridView();
            this.panelTransport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTransport)).BeginInit();
            this.SuspendLayout();
            // 
            // panelTransport
            // 
            this.panelTransport.Controls.Add(this.lblFillall);
            this.panelTransport.Controls.Add(this.cboxAvailable);
            this.panelTransport.Controls.Add(this.lblAvailable);
            this.panelTransport.Controls.Add(this.textModel);
            this.panelTransport.Controls.Add(this.textBrand);
            this.panelTransport.Controls.Add(this.textRegNo);
            this.panelTransport.Controls.Add(this.textFare);
            this.panelTransport.Controls.Add(this.lblFare);
            this.panelTransport.Controls.Add(this.lebelRegNo);
            this.panelTransport.Controls.Add(this.btnDelete);
            this.panelTransport.Controls.Add(this.btnUpdate);
            this.panelTransport.Controls.Add(this.labelModel);
            this.panelTransport.Controls.Add(this.btnAdd);
            this.panelTransport.Controls.Add(this.labelBrand);
            this.panelTransport.Controls.Add(this.labelType);
            this.panelTransport.Controls.Add(this.cboxType);
            this.panelTransport.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelTransport.Location = new System.Drawing.Point(0, 0);
            this.panelTransport.Name = "panelTransport";
            this.panelTransport.Size = new System.Drawing.Size(429, 552);
            this.panelTransport.TabIndex = 1;
            // 
            // lblFillall
            // 
            this.lblFillall.AutoSize = true;
            this.lblFillall.BackColor = System.Drawing.Color.Transparent;
            this.lblFillall.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFillall.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblFillall.Location = new System.Drawing.Point(79, 468);
            this.lblFillall.Name = "lblFillall";
            this.lblFillall.Size = new System.Drawing.Size(130, 20);
            this.lblFillall.TabIndex = 56;
            this.lblFillall.Text = "*Fill all the details";
            this.lblFillall.Visible = false;
            // 
            // cboxAvailable
            // 
            this.cboxAvailable.AllowDrop = true;
            this.cboxAvailable.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cboxAvailable.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxAvailable.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxAvailable.FormattingEnabled = true;
            this.cboxAvailable.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cboxAvailable.Location = new System.Drawing.Point(171, 304);
            this.cboxAvailable.MaxDropDownItems = 7;
            this.cboxAvailable.Name = "cboxAvailable";
            this.cboxAvailable.Size = new System.Drawing.Size(169, 27);
            this.cboxAvailable.TabIndex = 55;
            // 
            // lblAvailable
            // 
            this.lblAvailable.AutoSize = true;
            this.lblAvailable.BackColor = System.Drawing.Color.Transparent;
            this.lblAvailable.Font = new System.Drawing.Font("Times New Roman", 13.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvailable.Location = new System.Drawing.Point(79, 308);
            this.lblAvailable.Name = "lblAvailable";
            this.lblAvailable.Size = new System.Drawing.Size(83, 20);
            this.lblAvailable.TabIndex = 54;
            this.lblAvailable.Text = "Available :";
            // 
            // textModel
            // 
            this.textModel.AcceptsReturn = true;
            this.textModel.BackColor = System.Drawing.Color.Transparent;
            this.textModel.BorderRadius = 7;
            this.textModel.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textModel.DefaultText = "";
            this.textModel.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textModel.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textModel.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textModel.DisabledState.Parent = this.textModel;
            this.textModel.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textModel.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textModel.FocusedState.Parent = this.textModel;
            this.textModel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textModel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textModel.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textModel.HoverState.Parent = this.textModel;
            this.textModel.Location = new System.Drawing.Point(170, 216);
            this.textModel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textModel.Name = "textModel";
            this.textModel.PasswordChar = '\0';
            this.textModel.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textModel.PlaceholderText = "";
            this.textModel.SelectedText = "";
            this.textModel.ShadowDecoration.Parent = this.textModel;
            this.textModel.Size = new System.Drawing.Size(170, 27);
            this.textModel.TabIndex = 53;
            // 
            // textBrand
            // 
            this.textBrand.AcceptsReturn = true;
            this.textBrand.BackColor = System.Drawing.Color.Transparent;
            this.textBrand.BorderRadius = 7;
            this.textBrand.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBrand.DefaultText = "";
            this.textBrand.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textBrand.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textBrand.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textBrand.DisabledState.Parent = this.textBrand;
            this.textBrand.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textBrand.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textBrand.FocusedState.Parent = this.textBrand;
            this.textBrand.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBrand.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBrand.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textBrand.HoverState.Parent = this.textBrand;
            this.textBrand.Location = new System.Drawing.Point(170, 170);
            this.textBrand.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBrand.Name = "textBrand";
            this.textBrand.PasswordChar = '\0';
            this.textBrand.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textBrand.PlaceholderText = "";
            this.textBrand.SelectedText = "";
            this.textBrand.ShadowDecoration.Parent = this.textBrand;
            this.textBrand.Size = new System.Drawing.Size(170, 27);
            this.textBrand.TabIndex = 52;
            // 
            // textRegNo
            // 
            this.textRegNo.AcceptsReturn = true;
            this.textRegNo.BackColor = System.Drawing.Color.Transparent;
            this.textRegNo.BorderRadius = 7;
            this.textRegNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textRegNo.DefaultText = "";
            this.textRegNo.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textRegNo.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textRegNo.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textRegNo.DisabledState.Parent = this.textRegNo;
            this.textRegNo.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textRegNo.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textRegNo.FocusedState.Parent = this.textRegNo;
            this.textRegNo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textRegNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textRegNo.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textRegNo.HoverState.Parent = this.textRegNo;
            this.textRegNo.Location = new System.Drawing.Point(171, 85);
            this.textRegNo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textRegNo.Name = "textRegNo";
            this.textRegNo.PasswordChar = '\0';
            this.textRegNo.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textRegNo.PlaceholderText = "";
            this.textRegNo.SelectedText = "";
            this.textRegNo.ShadowDecoration.Parent = this.textRegNo;
            this.textRegNo.Size = new System.Drawing.Size(169, 27);
            this.textRegNo.TabIndex = 51;
            // 
            // textFare
            // 
            this.textFare.AcceptsReturn = true;
            this.textFare.BackColor = System.Drawing.Color.Transparent;
            this.textFare.BorderRadius = 7;
            this.textFare.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textFare.DefaultText = "";
            this.textFare.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.textFare.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.textFare.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textFare.DisabledState.Parent = this.textFare;
            this.textFare.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.textFare.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textFare.FocusedState.Parent = this.textFare;
            this.textFare.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textFare.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textFare.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.textFare.HoverState.Parent = this.textFare;
            this.textFare.Location = new System.Drawing.Point(186, 260);
            this.textFare.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textFare.Name = "textFare";
            this.textFare.PasswordChar = '\0';
            this.textFare.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.textFare.PlaceholderText = "";
            this.textFare.SelectedText = "";
            this.textFare.ShadowDecoration.Parent = this.textFare;
            this.textFare.Size = new System.Drawing.Size(154, 27);
            this.textFare.TabIndex = 42;
            // 
            // lblFare
            // 
            this.lblFare.AutoSize = true;
            this.lblFare.BackColor = System.Drawing.Color.Transparent;
            this.lblFare.Font = new System.Drawing.Font("Times New Roman", 13.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFare.Location = new System.Drawing.Point(79, 263);
            this.lblFare.Name = "lblFare";
            this.lblFare.Size = new System.Drawing.Size(96, 20);
            this.lblFare.TabIndex = 13;
            this.lblFare.Text = "Fare per H :";
            // 
            // lebelRegNo
            // 
            this.lebelRegNo.AutoSize = true;
            this.lebelRegNo.BackColor = System.Drawing.Color.Transparent;
            this.lebelRegNo.Font = new System.Drawing.Font("Times New Roman", 13.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lebelRegNo.Location = new System.Drawing.Point(79, 87);
            this.lebelRegNo.Name = "lebelRegNo";
            this.lebelRegNo.Size = new System.Drawing.Size(73, 20);
            this.lebelRegNo.TabIndex = 10;
            this.lebelRegNo.Text = "Reg No :";
            // 
            // btnDelete
            // 
            this.btnDelete.BorderRadius = 20;
            this.btnDelete.CheckedState.Parent = this.btnDelete;
            this.btnDelete.CustomImages.Parent = this.btnDelete;
            this.btnDelete.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDelete.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnDelete.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnDelete.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnDelete.DisabledState.Parent = this.btnDelete;
            this.btnDelete.FillColor = System.Drawing.Color.IndianRed;
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.HoverState.Parent = this.btnDelete;
            this.btnDelete.Location = new System.Drawing.Point(295, 391);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.ShadowDecoration.Parent = this.btnDelete;
            this.btnDelete.Size = new System.Drawing.Size(81, 45);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.Text = "Delete";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BorderRadius = 20;
            this.btnUpdate.CheckedState.Parent = this.btnUpdate;
            this.btnUpdate.CustomImages.Parent = this.btnUpdate;
            this.btnUpdate.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnUpdate.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnUpdate.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnUpdate.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnUpdate.DisabledState.Parent = this.btnUpdate;
            this.btnUpdate.FillColor = System.Drawing.Color.IndianRed;
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.HoverState.Parent = this.btnUpdate;
            this.btnUpdate.Location = new System.Drawing.Point(188, 391);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.ShadowDecoration.Parent = this.btnUpdate;
            this.btnUpdate.Size = new System.Drawing.Size(81, 45);
            this.btnUpdate.TabIndex = 7;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // labelModel
            // 
            this.labelModel.AutoSize = true;
            this.labelModel.BackColor = System.Drawing.Color.Transparent;
            this.labelModel.Font = new System.Drawing.Font("Times New Roman", 13.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelModel.Location = new System.Drawing.Point(79, 220);
            this.labelModel.Name = "labelModel";
            this.labelModel.Size = new System.Drawing.Size(64, 20);
            this.labelModel.TabIndex = 6;
            this.labelModel.Text = "Model :";
            // 
            // btnAdd
            // 
            this.btnAdd.BorderRadius = 20;
            this.btnAdd.CheckedState.Parent = this.btnAdd;
            this.btnAdd.CustomImages.Parent = this.btnAdd;
            this.btnAdd.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnAdd.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnAdd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnAdd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnAdd.DisabledState.Parent = this.btnAdd;
            this.btnAdd.FillColor = System.Drawing.Color.IndianRed;
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.HoverState.Parent = this.btnAdd;
            this.btnAdd.Location = new System.Drawing.Point(78, 391);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.ShadowDecoration.Parent = this.btnAdd;
            this.btnAdd.Size = new System.Drawing.Size(81, 45);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // labelBrand
            // 
            this.labelBrand.AutoSize = true;
            this.labelBrand.BackColor = System.Drawing.Color.Transparent;
            this.labelBrand.Font = new System.Drawing.Font("Times New Roman", 13.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBrand.Location = new System.Drawing.Point(79, 174);
            this.labelBrand.Name = "labelBrand";
            this.labelBrand.Size = new System.Drawing.Size(62, 20);
            this.labelBrand.TabIndex = 3;
            this.labelBrand.Text = "Brand :";
            // 
            // labelType
            // 
            this.labelType.AutoSize = true;
            this.labelType.BackColor = System.Drawing.Color.Transparent;
            this.labelType.Font = new System.Drawing.Font("Times New Roman", 13.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelType.Location = new System.Drawing.Point(79, 128);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(55, 20);
            this.labelType.TabIndex = 1;
            this.labelType.Text = "Type :";
            // 
            // cboxType
            // 
            this.cboxType.AllowDrop = true;
            this.cboxType.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cboxType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxType.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxType.FormattingEnabled = true;
            this.cboxType.Items.AddRange(new object[] {
            "Ambulane",
            "Bus",
            "Car",
            "Jeep",
            "Microbus",
            "Motorbike",
            "Pickup-van",
            "Truck"});
            this.cboxType.Location = new System.Drawing.Point(170, 126);
            this.cboxType.MaxDropDownItems = 7;
            this.cboxType.Name = "cboxType";
            this.cboxType.Size = new System.Drawing.Size(170, 27);
            this.cboxType.TabIndex = 0;
            // 
            // lblTransportList
            // 
            this.lblTransportList.AutoSize = true;
            this.lblTransportList.BackColor = System.Drawing.Color.Transparent;
            this.lblTransportList.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTransportList.Location = new System.Drawing.Point(629, 26);
            this.lblTransportList.Name = "lblTransportList";
            this.lblTransportList.Size = new System.Drawing.Size(135, 25);
            this.lblTransportList.TabIndex = 3;
            this.lblTransportList.Text = "Transport List";
            // 
            // dataGridTransport
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dataGridTransport.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridTransport.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridTransport.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridTransport.BackgroundColor = System.Drawing.Color.White;
            this.dataGridTransport.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridTransport.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridTransport.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.IndianRed;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridTransport.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridTransport.ColumnHeadersHeight = 22;
            this.dataGridTransport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridTransport.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridTransport.EnableHeadersVisualStyles = false;
            this.dataGridTransport.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataGridTransport.Location = new System.Drawing.Point(435, 87);
            this.dataGridTransport.Name = "dataGridTransport";
            this.dataGridTransport.ReadOnly = true;
            this.dataGridTransport.RowHeadersVisible = false;
            this.dataGridTransport.RowTemplate.Height = 26;
            this.dataGridTransport.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridTransport.Size = new System.Drawing.Size(566, 406);
            this.dataGridTransport.TabIndex = 2;
            this.dataGridTransport.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dataGridTransport.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dataGridTransport.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dataGridTransport.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dataGridTransport.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dataGridTransport.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dataGridTransport.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataGridTransport.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Maroon;
            this.dataGridTransport.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridTransport.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridTransport.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dataGridTransport.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridTransport.ThemeStyle.HeaderStyle.Height = 22;
            this.dataGridTransport.ThemeStyle.ReadOnly = true;
            this.dataGridTransport.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.Gray;
            this.dataGridTransport.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridTransport.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridTransport.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dataGridTransport.ThemeStyle.RowsStyle.Height = 26;
            this.dataGridTransport.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dataGridTransport.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dataGridTransport.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridTransport_CellContentClick);
            // 
            // FormTransport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1013, 552);
            this.Controls.Add(this.lblTransportList);
            this.Controls.Add(this.dataGridTransport);
            this.Controls.Add(this.panelTransport);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormTransport";
            this.Text = "Transports";
            this.Load += new System.EventHandler(this.FormTransport_Load);
            this.panelTransport.ResumeLayout(false);
            this.panelTransport.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTransport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelTransport;
        private Guna.UI2.WinForms.Guna2TextBox textFare;
        private System.Windows.Forms.Label lblFare;
        private System.Windows.Forms.Label lebelRegNo;
        private Guna.UI2.WinForms.Guna2Button btnDelete;
        private Guna.UI2.WinForms.Guna2Button btnUpdate;
        private System.Windows.Forms.Label labelModel;
        private Guna.UI2.WinForms.Guna2Button btnAdd;
        private System.Windows.Forms.Label labelBrand;
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.ComboBox cboxType;
        private Guna.UI2.WinForms.Guna2TextBox textRegNo;
        private Guna.UI2.WinForms.Guna2TextBox textModel;
        private Guna.UI2.WinForms.Guna2TextBox textBrand;
        private System.Windows.Forms.Label lblAvailable;
        private System.Windows.Forms.Label lblTransportList;
        private System.Windows.Forms.ComboBox cboxAvailable;
        private System.Windows.Forms.Label lblFillall;
        private Guna.UI2.WinForms.Guna2DataGridView dataGridTransport;
    }
}